import sensor, image, time, pyb
from pyb import UART

blue = (4, 30, 0, 54, -22, -77)
red =  (11, 56, 31, 84, 18, 64)
green = (35, 75, -62, -32, 5, 43)
#(29, 70, -64, -30, 7, 46)
#(27, 69, -80, -34, 8, 44)
color_roi = (64,81,173,81)

uart = UART(3, 19200)

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_whitebal(False)
sensor.set_auto_gain(False)



'''def find_group():
    for i in range(3):
        j = i + 1
        for j in range(3):
            if group_1[i] < group_1[j]:
                group_1[i],group_1[j] = group_1[j],group_1[i]
                numbers_1[i],numbers_1[j] = numbers_1[j],numbers_1[i]
            if group_2[i] < group_2[j]:
                group_2[i],group_2[j] = group_2[j],group_2[i]
                numbers_2[i],numbers_2[j] = numbers_2[j],numbers_2[i]

def Juege_1():
    Sum = numbers_1[0]*100 + numbers_1[1]*10 + numbers_1[2]
    uart.write(str(Sum))

def Juege_2():
    Sum = numbers_2[0]*100 + numbers_2[1]*10 + numbers_2[2]
    uart.write(str(Sum))'''


while(True):
    f = 0
    x = 64
    x0 = 10
    thresholds = [[red],[green],[blue]]
    numbers_1 = [0,0,0]
    numbers_2 = [0,0,0]

    img = sensor.snapshot().lens_corr(1.5)
    sum_down = 0
    sum_up = 0
    for i in range(3):
        for b in img.find_blobs(thresholds[i],roi = color_roi,pixels_threshold = 100,area_threshold = 100,merge = True):
            if b:
                    #img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())

                if ( b.cy() < 120 and b.pixels()<1200 ):
                    if (i==2):
                        sum_up += i+2
                    else:
                        sum_up += i+1
                    if (b.cx()-x > 26-x0 and b.cx()-x < 26+x0):
                        numbers_1[0] = i+1
                    elif (b.cx()-x > 88-x0 and b.cx()-x < 88+x0):
                        numbers_1[1] = i+1
                    elif (b.cx()-x > 149-x0 and b.cx()-x < 149+x0):
                        numbers_1[2] = i+1
                if ( b.cy() > 120 and b.pixels()<1200 ):
                    if (i==2):
                        sum_down += i+2
                    else:
                        sum_down += i+1
                    if (b.cx()-x > 31-x0 and b.cx()-x < 31+x0):
                        numbers_2[0] = i+1
                    elif (b.cx()-x > 91-x0 and b.cx()-x < 91+x0):
                        numbers_2[1] = i+1
                    elif (b.cx()-x > 143-x0 and b.cx()-x < 143+x0):
                        numbers_2[2] = i+1

        if(sum_up == 1 or sum_up == 2 or sum_up == 4):
            first_1 = numbers_1.index(0)
            if (sum_up == 2):
                numbers_1[first_1] = 1
            else:
                numbers_1[first_1] = 2

        if(sum_down == 1 or sum_down == 2 or sum_down == 4):
            first_2 = numbers_2.index(0)
            if (sum_down == 2):
                numbers_2[first_2] = 1
            else:
                numbers_2[first_2] = 2

    if (numbers_1[0]==0 or numbers_1[1]==0 or numbers_1[2]==0):
        code = 6 - numbers_1[0] - numbers_1[1] - numbers_1[2]
        first_1 = numbers_1.index(0)
        numbers_1[first_1] = code

    if (numbers_2[0]==0 or numbers_2[1]==0 or numbers_2[2]==0):
        code = 6 - numbers_2[0] - numbers_2[1] - numbers_2[2]
        first_2 = numbers_2.index(0)
        numbers_2[first_2] = code

    print(numbers_1)
    print(numbers_2)
    #print("----------------")
    #time.sleep(2)




