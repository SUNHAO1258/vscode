import sensor, image, time, pyb
from pyb import UART


#------------------初赛物料-------------------#
red =  (11, 69, 9, 91, -13, 70)
green = (35, 85, -70, -32, 5, 48)
blue = (18, 46, 33, -11, -58, -16)

thresholds = [[red],[green],[blue]]

color_roijuesai = (0,69,321,88)

uart = UART(3, 19200)

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_whitebal(False)
sensor.set_auto_gain(False)


'''def find_group():
    for i in range(3):
        j = i + 1
        for j in range(3):
            if group_1[i] < group_1[j]:
                group_1[i],group_1[j] = group_1[j],group_1[i]
                numbers_1[i],numbers_1[j] = numbers_1[j],numbers_1[i]
            if group_2[i] < group_2[j]:
                group_2[i],group_2[j] = group_2[j],group_2[i]
                numbers_2[i],numbers_2[j] = numbers_2[j],numbers_2[i]

def Juege_1():
    Sum = numbers_1[0]*100 + numbers_1[1]*10 + numbers_1[2]
    uart.write(str(Sum))

def Juege_2():
    Sum = numbers_2[0]*100 + numbers_2[1]*10 + numbers_2[2]
    uart.write(str(Sum))'''


def find_colorsjuesai():
    f = 0
    x = 70
    x0 = 20
    sum_up = 0

    for i in range(3):
        for b in img.find_blobs(thresholds[i],roi = color_roijuesai,pixels_threshold = 100,area_threshold = 500,merge = True):
            if b:
                #img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                sum_up += i+1
                if (b.cx() > 0 and b.cx() < 80):
                    numbers_1[0] = i+1
                elif (b.cx() > 134 and b.cx() < 200):
                    numbers_1[1] = i+1
                elif (b.cx() > 250 and b.cx()-x < 310):
                    numbers_1[2] = i+1


    if(numbers_1.count(0) == 2):
        first_1 = numbers_1.index(0)
        if (sum_up == 2):
            numbers_1[first_1] = 1
        else:
            numbers_1[first_1] = 2

    if (numbers_1.count(0) == 1):
        code = 6 - numbers_1[0] - numbers_1[1] - numbers_1[2]
        first_1 = numbers_1.index(0)
        numbers_1[first_1] = code


while(True):
    img = sensor.snapshot().lens_corr(1.5)
    numbers_1 = [0,0,0]
    find_colorsjuesai()
    print("---------a---------")
    print(numbers_1)
    #print("---------b------------")
    #print(numbers_2)
    '''if (uart.any()):
        flag = uart.readchar()
        if(flag == 97):
                 #print("物块")
            flag='z'
            for i in range(3):
                if(numbers_1[i]==1):
                    uart.write('1')
                if(numbers_1[i]==2):
                    uart.write('2')
                if(numbers_1[i]==3):
                    uart.write('3')
                   #print(str(numbers_1[i]))
            for i in range(3):
                if(numbers_2[i]==1):
                    uart.write('1')
                if(numbers_2[i]==2):
                    uart.write('2')
                if(numbers_2[i]==3):
                    uart.write('3')
                   #print(str(numbers_2[i]))
        elif(flag == 83):
                   #print("颜色识别收到s")
            break'''
