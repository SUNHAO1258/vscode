import sensor, image, time

green_threshold = (54, 97, -83, -24, 5, 78)#绿色阈值
red_threshold = (10, 55, 12, 72, -3, 59)#红色阈值
blue_threshold = (10, 60, 6, 64, -100, -28)#蓝色阈值
green_coordinate = [0,0]#绿色坐标
red_coordinate = [0,0]#红色坐标
blue_coordinate = [0,0]#蓝色坐标
left_roi = [0,0,320,240]#中心区域
time_start_green = 0
time_start_red = 0
time_start_blue = 0
stop_flag = 0

sensor.reset() # 初始化摄像头
sensor.set_pixformat(sensor.RGB565) # 格式为 RGB565.
sensor.set_framesize(sensor.QVGA) # 使用 QQVGA 速度快一些
sensor.skip_frames(time = 2000) # 跳过2000s，使新设置生效,并自动调节白平衡
sensor.set_auto_gain(False) # 关闭自动自动增益。默认开启的，在颜色识别中，一定要关闭白平衡。
sensor.set_auto_whitebal(False)

clock = time.clock() # 追踪帧率


while(True):
    clock.tick()
    img = sensor.snapshot()
    img.draw_rectangle(left_roi) # 识别区域
    blobs = img.find_blobs([green_threshold],roi = left_roi,x_stride = 10,y_stride = 10,pixels_threshold = 1600,merge = True)
    if blobs:
     #如果找到了目标颜色
        for b in blobs:
        #迭代找到的目标颜色区域
            # Draw a rect around the blob.
            img.draw_rectangle(b[0:4], color = (0,255,0)) # rect
            #用矩形标记出目标颜色区域
            img.draw_cross(b[5], b[6]) # cx, cy
            #在目标颜色区域的中心画十字形标记
            #print(green_coordinate)
            if (time.ticks_ms() - time_start_green) > 500:#判断时间过去1秒
                time_start_green = time.ticks_ms()#更新时间戳
                if (abs(green_coordinate[0]-b[5])<2):
                    stop_flag = 1#判断停止
                else:
                    stop_flag = 0#判断未停止
                green_coordinate[0] = b[5]#绿色坐标x
                green_coordinate[1] = b[6]#绿色坐标y

    blobs = img.find_blobs([red_threshold],roi = left_roi,x_stride = 10,y_stride = 10,pixels_threshold = 1600,merge = True)
    if blobs:
     #如果找到了目标颜色
        for b in blobs:
        #迭代找到的目标颜色区域
            # Draw a rect around the blob.
            img.draw_rectangle(b[0:4], color = (255,0,0)) # rect
            #用矩形标记出目标颜色区域
            img.draw_cross(b[5], b[6]) # cx, cy
            #在目标颜色区域的中心画十字形标记
            #print(red_coordinate)
            if (time.ticks_ms() - time_start_red) > 500:#判断时间过去1秒
                time_start_red = time.ticks_ms()#更新时间戳
                if (abs(red_coordinate[0]-b[5])<2):
                    stop_flag = 1#判断停止
                else:
                    stop_flag = 0#判断未停止
                    red_coordinate[0] = b[5]#绿色坐标x
                    red_coordinate[1] = b[6]#绿色坐标y
    blobs = img.find_blobs([blue_threshold],roi = left_roi,x_stride = 10,y_stride = 10,pixels_threshold = 1600,merge = True)
    if blobs:
     #如果找到了目标颜色
        for b in blobs:
        #迭代找到的目标颜色区域
            # Draw a rect around the blob.
            img.draw_rectangle(b[0:4], color = (0,0,255)) # rect
            #用矩形标记出目标颜色区域
            img.draw_cross(b[5], b[6]) # cx, cy
            #在目标颜色区域的中心画十字形标记
            #print(blue_coordinate)
            if (time.ticks_ms() - time_start_blue) > 500:#判断时间过去1秒
                time_start_blue = time.ticks_ms()#更新时间戳
                if (abs(blue_coordinate[0]-b[5])<2):
                    stop_flag = 1#判断停止
                else:
                    stop_flag = 0#判断未停止
                    blue_coordinate[0] = b[5]#绿色坐标x
                    blue_coordinate[1] = b[6]#绿色坐标y
    #print(clock.fps())
    print(stop_flag)
