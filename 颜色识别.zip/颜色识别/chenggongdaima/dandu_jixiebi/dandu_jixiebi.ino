void setup() {
  // put your setup code here, to run once:
    pinMode(48, OUTPUT);
    digitalWrite(48, HIGH);
    Serial3.print('s');
    pinMode(8, INPUT);
    digitalWrite(8, HIGH);
    pinMode(10, INPUT);
    digitalWrite(10, HIGH);


}

void loop() {
  // put your main code here, to run repeatedly:

}
