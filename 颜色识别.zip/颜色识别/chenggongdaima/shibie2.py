import sensor, image, time

green_threshold = (54, 97, -83, -24, 5, 78)
red_threshold = (10, 55, 12, 72, -3, 59)
blue_threshold = (10, 60, 6, 64, -100, -28)
green_coordinate = [0,0]
red_coordinate = [0,0]
blue_coordinate = [0,0]
left_roi = [0,0,320,240]
time_start_green = 0
time_start_red = 0
time_start_blue = 0
stop_flag = 0

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)

clock = time.clock()


while(True):
    clock.tick()
    img = sensor.snapshot()
    img.draw_rectangle(left_roi)
    blobs = img.find_blobs([green_threshold],roi = left_roi,x_stride = 10,y_stride = 10,pixels_threshold = 1600,merge = True)
    if blobs:
        for b in blobs:
            img.draw_rectangle(b[0:4], color = (0,255,0))
            img.draw_cross(b[5], b[6])
            if (time.ticks_ms() - time_start_green) > 500:
                time_start_green = time.ticks_ms()
                if (abs(green_coordinate[0]-b[5])<2):
                    stop_flag = 1
                else:
                    stop_flag = 0
                green_coordinate[0] = b[5]
                green_coordinate[1] = b[6]

    blobs = img.find_blobs([red_threshold],roi = left_roi,x_stride = 10,y_stride = 10,pixels_threshold = 1600,merge = True)
    if blobs:
        for b in blobs:
            img.draw_rectangle(b[0:4], color = (255,0,0))
            img.draw_cross(b[5], b[6])
            if (time.ticks_ms() - time_start_red) > 500:
                time_start_red = time.ticks_ms()
                if (abs(red_coordinate[0]-b[5])<2):
                    stop_flag = 1
                else:
                    stop_flag = 0
                    red_coordinate[0] = b[5]
                    red_coordinate[1] = b[6]
    blobs = img.find_blobs([blue_threshold],roi = left_roi,x_stride = 10,y_stride = 10,pixels_threshold = 1600,merge = True)
    if blobs:
        for b in blobs:
            # Draw a rect around the blob.
            img.draw_rectangle(b[0:4], color = (0,0,255))
            img.draw_cross(b[5], b[6])
            if (time.ticks_ms() - time_start_blue) > 500:
                time_start_blue = time.ticks_ms()
                if (abs(blue_coordinate[0]-b[5])<2):
                    stop_flag = 1
                else:
                    stop_flag = 0
                    blue_coordinate[0] = b[5]
                    blue_coordinate[1] = b[6]
    #print(clock.fps())
    print(stop_flag)
