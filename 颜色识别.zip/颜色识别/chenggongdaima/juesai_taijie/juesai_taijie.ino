void setup() {
  // put your setup code here, to run once:

}
void juesai_tj(){
  int group1[3] = {};
  int biaozhi=1;
  while(biaozhi==1){
    for (int i = 0; i < 3; i++) {
    if (Serial3.available() > 0) {
        temp = Serial3.read();
        Serial.print("the Serial3 reading data is : ");
        Serial.println(temp);
        group1[i]=temp;
        temp=0;
      }
  }
}
  biaozhi=0;
  for (int i = 0; i < 3; i++) {
    switch (group1[i]) {
      case 1:
      delay(1000);
        ServoActiongroup(10);
        delay(12600);
        Serial.print("6");
        break;
      case 2:
        delay(1000);
        ServoActiongroup(11);
        delay(12500);
        Serial.print("5");
        break;
      case 3:
        delay(1500);
        ServoActiongroup(12);
        delay(12000);
        // Serial.print("4");
        break;
      default:
        printf("Default case\n");
    }
  }
}
void loop() {
  // put your main code here, to run repeatedly:

}
