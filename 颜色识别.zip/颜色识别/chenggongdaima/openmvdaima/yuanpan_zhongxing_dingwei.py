# Hello World Example
#
# Welcome to the OpenMV IDE! Click on the green run arrow button below to run the script!

import sensor, image, time
from pyb import UART
white= (17, 58, 5, 17, -33, 33)#(78, 100, -128, 127, -128, 127)
uart = UART(3, 115200)

#image.find_blobs(thresholds, roi=Auto, x_stride=2, y_stride=1, invert=False, area_threshold=10, pixels_threshold=10, merge=False, margin=0, threshold_cb=None, merge_cb=None)
             # Create a clock object to track the FPS.
left_roi = [100,0,150,71]
while(True):
    #x0 = 100
    #y0 = 100
    #clock.tick()
    if (uart.any()):
        flag = uart.read()
        print(flag)
        if(flag == b'D'):
            sensor.reset()
            sensor.set_pixformat(sensor.RGB565)
            sensor.set_framesize(sensor.QVGA)
            sensor.skip_frames(time=2000)
            sensor.set_auto_gain(False)
            sensor.set_auto_whitebal(False)
        while(flag == b'd'):
            img = sensor.snapshot().lens_corr(1.5)
            blobs = img.find_blobs([white],roi=left_roi,merge=True,margin=10,pixels_threshold = 1000)
            if blobs:
                for c in blobs:
                    img.draw_rectangle(c.rect())
                    img.draw_cross(c.cx(), c.cy())
                    x_err=c.cx()-168
                    y_err=c.cy()-24
                    #print(x_err)
                    print(y_err)
                    if(abs(x_err) < 2 and abs(y_err) <2):
                        uart.write('5')
                        #y_err = 100
                        print("发送5")
                        flag='e'
                    if(abs(x_err) > 2):
                        if (x_err < 0):
                            uart.write('1')
                            #x_err = 100
                            print(x_err)
                            print("发送1")
                            print(flag)
                            flag='e'
                            break
                        if (x_err > 0):
                            uart.write('2')
                            #x_err = 100
                            #print(1)
                            print(x_err)
                            print("发送2")
                            flag='e'
                            break
                    if (abs(y_err) > 2):
                        #print("y")
                        if (y_err < 0):
                            uart.write('4')
                            #y_err = 100
                            print("发送4")
                            flag='e'
                            break
                        if (y_err > 0):
                            uart.write('3')
                            #y_err = 100
                            print("发送3")
                            flag='e'
                            break
            else:
                uart.write('4')
                #print("发送1")
                flag='e'
            #print(1)
