# Untitled - By: 娄欣颖 - 周日 4月 2 2023


import sensor, image, time
from pyb import UART
white=(47, 87, 11, 51, -93, -17)#(78, 100, -128, 127, -128, 127)
uart = UART(3, 115200)
left_roi = [0,119,147,105]
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time=2000)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
while(True):
    x_zong=0
    x_zui=0
    y_zong=0
    y_zui=0
    img = sensor.snapshot().lens_corr(1.5)
    blobs = img.find_blobs([white],roi=left_roi,merge=True,margin=10,pixels_threshold = 1000)
    if blobs:
        for c in blobs:
            img.draw_rectangle(c.rect())
            img.draw_cross(c.cx(), c.cy())
            x_err=c.cx()
            y_err=c.cy()
            #print(x_err)
            print(y_err)
            if(abs(y_err)>0):
                uart.write('5')
                #y_err = 100
                #print("发送5")
                flag='e'
    else:
        uart.write('4')
        #print("发送1")
        flag='e'




            #if(abs(x_err) > 2):
                #if (x_err < 0):
                    #uart.write('3')
                    ##x_err = 100
                    ##print(x_err)
                    ##print("发送3")
                    ##print(flag)
                    #flag='e'
                    #break
                #if (x_err > 0):
                    #uart.write('4')
                    ##x_err = 100
                    ##print(1)
                    ##print(x_err)
                    ##print("发送4")
                    #flag='e'
                    #break
            #if (abs(y_err) > 2):
                ##print("y")
                #if (y_err < 0):
                    #uart.write('1')
                    ##y_err = 100
                    ##print("发送1")
                    #flag='e'
                    #break
                #if (y_err > 0):
                    #uart.write('2')
                    ##y_err = 100
                    ##print("发送2")
                    #flag='e'
                    #break
