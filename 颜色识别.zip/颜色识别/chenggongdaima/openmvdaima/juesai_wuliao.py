# Untitled - By: 娄欣颖 - 周四 4月 13 2023
import sensor, image, time
blue = (26, 47, 3, 24, -61, -22)#(0, 47, -128, 31, -128, -13)
red = (27, 66, -1, 63, 6, 38)#(14, 40, 18, 52, 1, 127)
green =(15, 40, -36, -4, -7, 30)
thresholds = [[red],[green],[blue]]
biaozhi=1
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_whitebal(False)
sensor.set_auto_gain(False)

#clock = time.clock()

def juesai_wuliao_1():
    global group_1
    group_1=[0,0,0]
    global numbers_1
    numbers_1=[0,0,0]
    img1 = sensor.snapshot().lens_corr(2.0)
    while(biaozhi==1):
        for i in range(3):
            #flag = 0
            blobs = img1.find_blobs(thresholds[i],pixels_threshold =50,area_threshold = 50,merge =True)
            if blobs:
                for b in blobs:
                    img1.draw_rectangle(b.rect())
                    img1.draw_cross(b.cx(),b.cy())
                    group_1[i]=b.cx()
                    numbers_1[i]=i+1
                    #print(newx)
                    #print(xunzhao)
            else:
                pass
        for i in range(3):
            j = i + 1
            for j in range(3):
                if group_1[i] < group_1[j]:
                    group_1[i],group_1[j] = group_1[j],group_1[i]
                    numbers_1[i],numbers_1[j] = numbers_1[j],numbers_1[i]
        #print(group_1)
        print(numbers_1)
def juesai_wuliao_2():
    global group_2
    global numbers_2
    img1 = sensor.snapshot().lens_corr(2.0)
    for i in range(3):
        #flag = 0
        blobs = img1.find_blobs(thresholds[i],pixels_threshold =50,area_threshold = 50,merge =True)
        if blobs:
            for b in blobs:
                img1.draw_rectangle(b.rect())
                img1.draw_cross(b.cx(),b.cy())
                group_2[i]=b.cx()
                numbers_2[i]=i+1
                print(newx)
                print(xunzhao)
                for i in range(3):
                    j = i + 1
                    for j in range(3):
                        if group_2[i] < group_2[j]:
                            group_2[i],group_2[j] = group_2[j],group_2[i]
                            numbers_2[i],numbers_2[j] = numbers_2[j],numbers_2[i]
        else:
            pass
def chuanshu():
    global numbers_1
    for i in range(3):
        a=number_1[i]
        uart.write(a)



while(True):
    juesai_wuliao_1()
    chuanshu()
