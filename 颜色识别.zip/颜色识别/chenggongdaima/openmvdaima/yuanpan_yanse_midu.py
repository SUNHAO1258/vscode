import sensor, image, time
from pyb import UART
blue = (13, 39, 13, 43, -25, 127)
red =  (38, 53, 26, 75, -42, 25)
green = (33, 59, -11, 15, -48, 3)

thresholds = [[red],[green],[blue]]
left_roi = [87,0,146,101]
def jieshou():
    global FLAG
    global a
    a=0
    while(FLAG!=6):
        FLAG=0
        if (uart.any()):
            a=uart.read()
            a=str(a)
            #print(a)
            for i in range(0,3):
                code_1[i] = int(a[2+i])
                FLAG=FLAG+1
                print(code_1[i])
            for i in range(0,3):
                code_2[i] = int(a[5+i])
                FLAG=FLAG+1
                print(code_2[i])
def find_stopstate():
    global blobs
    blobs =0
    global state
    state=0
    global yanse
    yanse=[0,0,0]
    global state_1
    #设置原来物料的位置
    group_oldx=[999 for x in range(3)]
    group_oldy=[999 for x in range(3)]
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = 100,area_threshold = 100,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                group_oldx[i]=b.cx()
                group_oldy[i]=b.cy()
                yanse[i]=i+1
        else:
            group_oldx[i]=0
            group_oldy[i]=0
    while(state==0):
        get_new()
        if(group_oldx[1]==0 and group_oldx[2]==0 and group_oldx[0]==0 and group_newx[1]==0 and group_newx[2]==0 and group_newx[0]==0):
            state=0
            #print('等待')
        elif(abs(group_oldx[1]-group_newx[1])<2 and abs(group_oldx[2]-group_newx[2])<2 and abs(group_oldx[0]-group_newx[0])<2):
            while(state_1==0):
                    get_new_color()
                    if(yanse[1]-yanse_new[1]==0 and yanse[2]-yanse_new[2]==0 and yanse[0]-yanse_new[0]==0 ):
                        yanse = yanse_new
                    else:
                        state_1=1
                        print(yanse_new)
                        print(yanse)
                        print('jieshou')
                        find_stop()
            state=1
            #print('找到')
        else:
            #print(group_oldx)
            #print(group_newx)
            group_oldx = group_newx
            group_oldy = group_newy
            pass
def get_new_color():
    global yanse_new
    yanse_new=[0 for x in range(3)]
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = 100,area_threshold = 100,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                #group_newx[i]=b.cx()
                yanse_new[i]=i+1
        else:
            pass

def get_new():
    global group_newx
    global group_newy
    group_newx=[0 for x in range(3)]
    group_newy=[0 for x in range(3)]
    sensor.skip_frames(time = 100)
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = 100,area_threshold = 100,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                group_newx[i]=b.cx()
        else:
            pass

def xunzhao_wuliao():
    global xunzhao
    global chongxing
    xunzhao=[0,0,0]
    k=0
    chongxing=1
    global blobs
    blobs =0
    global biaozhi
    biaozhi=0
    while(biaozhi==0):
        sensor.skip_frames(time = 500)
        img = sensor.snapshot().lens_corr(1.5)
        for i in range(3):
            blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = 100,area_threshold = 100,merge = True)
            if blobs:
                for b in blobs:
                    img.draw_rectangle(b.rect())
                    img.draw_cross(b.cx(), b.cy())
                    newx[i]=b.cx()
                    xunzhao[i]=i+1
                    #print('到')
                    #print(newx)
                    print(xunzhao)
                    if b.density() > 0.7 : #blob.density()返回色块密度
                        biaozhi=1
                        break
                    else:
                        for k in range(3):
                            if(xunzhao[k]==code_1[jishu]):
                                uart.write(str('o'))
                                print('0')
                                #time.sleep(5)
                                #find_stopstate()
                                #sensor.skip_frames(time = 1000)
                                time.sleep(6)
                                break
                            else:
                                pass
            else:
                pass

#第二组颜色
def xunzhao_wuliao_1():
    global xunzhao
    global chongxing
    xunzhao=[0,0,0]
    k=0
    chongxing=1
    global blobs
    blobs =0
    sensor.skip_frames(time = 500)
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = 100,area_threshold = 100,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                newx[i]=b.cx()
                xunzhao[i]=i+1
                #print('到')
                print(newx)
                print(xunzhao)
        else:
            pass
    for k in range(3):
        if(xunzhao[k]==code_2[jishu_1]):
            if(k==0):
                uart.write(str('R'))
                print('R')
                #red_led = pyb.LED(1)
                #red_led.on
                #time.sleep(5)
                #find_stopstate()
                #sensor.skip_frames(time = 1000)
                time.sleep(3.5)
                break
            if(k==1):
                uart.write(str('G'))
                #green_led= pyb.LED(1)
                #green_led.on
                print('G')
                #time.sleep(5)
                #find_stopstate()
                #sensor.skip_frames(time = 1000)
                time.sleep(3.5)
                break
            if(k==2):
                uart.write(str('B'))
                #blue_led=pyb.LED(1)
                #blue_led.on
                print('B')
                #time.sleep(5)
                #find_stopstate()
                #sensor.skip_frames(time = 1000)
                time.sleep(3.5)
                break
while (True):
    global xunzhao
    if (uart.any()):
        flag = uart.read()
        print(flag)
    while(flag == b'c'):
        jieshou()
        break
    while(flag == b's'):
        sensor.reset()
        sensor.set_pixformat(sensor.RGB565)
        sensor.set_framesize(sensor.QVGA)
        sensor.skip_frames(time = 200)
        sensor.set_auto_whitebal(False)
        sensor.set_auto_gain(False)
        while(jishu!=3):
            find_stopstate()
            xunzhao_wuliao()
