import sensor, image, time
from pyb import UART
blue = (25, 61, 11, 41, -74, -37)
red =  (38, 53, 26, 75, -42, 25)
green = (33, 59, -11, 15, -48, 3)

thresholds = [[red],[green],[blue]]
left_roi = [114,7,143,51]
jishu=0
uart = UART(3, 115200)
state=0
biaozhi=0
def jieshou():
    global FLAG
    global a
    a=0
    while(FLAG!=6):
        FLAG=0
        if (uart.any()):
            a=uart.read()
            a=str(a)
            #print(a)
            for i in range(0,3):
                code_1[i] = int(a[2+i])
                FLAG=FLAG+1
                print(code_1[i])
            for i in range(0,3):
                code_2[i] = int(a[5+i])
                FLAG=FLAG+1
                print(code_2[i])

def find_stopstate():
    global blobs
    blobs =0
    global state
    global yanse
    yanse=[0,0,0]
    global state_1
    global biaozhi
    #设置原来物料的位置
    group_oldx=[999 for x in range(3)]
    group_oldy=[999 for x in range(3)]
    while(biaozhi==0):
        img = sensor.snapshot().lens_corr(1.5)
        for i in range(3):
            blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = 100,area_threshold = 100,merge = True)
            if blobs:
                for b in blobs:
                    img.draw_rectangle(b.rect())
                    img.draw_cross(b.cx(), b.cy())
                    #group_oldx[i]=b.cx()
                    #group_oldy[i]=b.cy()
                    yanse[i]=i+1
            else:
                pass
        while(state==0):
            get_new_color()
            if(yanse[1]-yanse_new[1]==0 and yanse[2]-yanse_new[2]==0 and yanse[0]-yanse_new[0]==0 ):
                yanse = yanse_new
            else:
                state=1
                #print(yanse_new)
                #print(yanse)
                print('jieshou')
                biaozhi=1


def color():
    global yanse_new
    b_z=0
    img = sensor.snapshot().lens_corr(1.5)
    while(b_z==0):
        for i in range(3):
            blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = 100,area_threshold = 100,merge = True)
            if blobs:
                for b in blobs:
                    img.draw_rectangle(b.rect())
                    img.draw_cross(b.cx(), b.cy())
                    #group_newx[i]=b.cx()
                    yanse_new[i]=i+1
                    print(yanse_new)
                    b_z=1
                    break
            else:
                pass
def get_new_color():
    global yanse_new
    yanse_new=[0 for x in range(3)]
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = 100,area_threshold = 100,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                #group_newx[i]=b.cx()
                yanse_new[i]=i+1
        else:
            pass

def xunzhao_wuliao():
    global jishu
    global chongxing
    xunzhao=[0,0,0]
    k=0
    chongxing=1
    global blobs
    blobs =0
    global yanse_new
    code_1=[2,1,3]
    code_2=[2,1,3]
    for k in range(3):
        if(yanse_new[k]==code_1[jishu]):
            uart.write(str('o'))
            print('o')
            flag='e'
            break
        else:
            pass


while (True):
    global xunzhao
    if (uart.any()):
        flag = uart.read()
        print(flag)
    while(flag == b'c'):
        jieshou()
        break
    if(flag == b'k'):
        sensor.reset()
        sensor.set_pixformat(sensor.RGB565)
        sensor.set_framesize(sensor.QVGA)
        sensor.skip_frames(time = 200)
        sensor.set_auto_whitebal(False)
        sensor.set_auto_gain(False)
    while(flag == b's'):
        find_stopstate()
        color()
        xunzhao_wuliao()
    while(flag == b'm'):
        time.sleep(4)
        flag='e'

