# Untitled - By: 娄欣颖 - 周三 4月 12 2023

import sensor, image, time

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
blue =(30, 60, -9, 41, -97, -5)
red =  (38, 53, 26, 75, -42, 25)
green = (42, 51, -32, -5, -30, 6)
pixels_threshold = 10
area_threshold = 10
thresholds = [[red],[green],[blue]]
group_oldx=[0,0,0]
group_oldy=[0,0,0]
left_roi = [106,1,112,55]
yanse=[0,0,0]
B=0
#clock = time.clock()

while(True):
    img = sensor.snapshot().gamma_corr(gamma=1.5, contrast=1.3, brightness=0.0)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i], pixels_threshold=pixels_threshold, area_threshold=area_threshold,merge = True,roi=left_roi,merge=10)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                group_oldx[i]=b.cx()
                group_oldy[i]=b.cy()
                yanse[i]=i+1
                if b.density() > 0.6 : #blob.density()返回色块密度
                    print(b.density())
                    print(1)
                else:
                    print(b.density())
                    print(2)
