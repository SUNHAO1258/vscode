# Untitled - By: 娄欣颖 - 周四 4月 13 2023

import sensor, image, time

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_whitebal(False)
sensor.set_auto_gain(False)
#clock = time.clock()

while(True):
    #clock.tick()
    img = sensor.snapshot().lens_corr(1.5)
    #print(clock.fps())
