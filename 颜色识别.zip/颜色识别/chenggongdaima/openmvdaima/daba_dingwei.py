import sensor, image, time, math,pyb
from pyb import UART

blue = (0, 47, -128, 31, -128, -13)
red =  (0, 56, 18, 127, -18, 127)
green = [(-255, 0), (-225, 0), (-225, 0)]
white_threshold =[(92, 100, -29, 127, -27, 21),
                  (75, 100, -11, 127, -10, 14)]
yuanpan=(0, 50, -4, 6, 7, 127)
thresholds = [[red],[green],[blue]]
group_oldx = 0
group_oldy = 0
x_err=0
y_err=0
flag = b"q"
biaozhi=0
jia=0
jia_1=0
y=0
x=0
uart = UART(3, 115200)
jieshou=1
#clock = time.clock()
while (True):
    if (uart.any()):
        flag = uart.read()
        print(flag)
        if(flag == b'D'):
            sensor.reset()
            sensor.set_pixformat(sensor.RGB565)
            sensor.set_framesize(sensor.QVGA)
            sensor.skip_frames(time=2000)
            sensor.set_auto_gain(False)
            sensor.set_auto_whitebal(False)
        while(flag == b'd'):
        #x0 = 100
        #y0 = 100

                    #clock.tick()

                        #print(1)
                        #for blob in img.find_blobs(white_threshold, x_stride=10, y_stride=10, roi=area_1, merge = True,margin = 10):
                            #print(2)
                            #print(blob.density())
                            #print(blob.area())
                            #if blob.density() > 0.7 and blob.area() > 1200:
                                #img.draw_rectangle(blob[0:4])
                                #print("2")

                                #print(x_err)
                                #print(y_err)
                                # if (uart.any()):
                                #     flag = uart.read()
                                #     if (flag == b'd'):
                                #         # print("收到d")
                #sensor.skip_frames(time = 500)
            img = sensor.snapshot().lens_corr(2.0).gamma_corr(gamma=1.5, contrast=1.3, brightness=0.0)
            for c in img.find_circles(threshold=3000, x_margin=20, y_margin=20, r_margin=30,r_min=2, r_max=200, r_step=2):
                area_1 = (c.x() - c.r(), c.y() - c.r(), 2 * c.r(), 2 * c.r())
                img.draw_rectangle(area_1, color=(0, 255, 255))  #area_threshold=100, pixels_threshold=900,
                x_err=c.x()-160
                y_err=c.y()-147
                print(x_err)
                print(6)
                print(y_err)
                if(abs(x_err) < 4 and abs(y_err) <4):
                    uart.write('5')
                    #y_err = 100
                    print("发送5")
                    flag='e'
                if(abs(x_err) > 2):
                    if (x_err < 0):
                        uart.write('3')
                        #x_err = 100
                        print(x_err)
                        print("发送3")
                        print(flag)
                        flag='e'
                        break
                    if (x_err > 0):
                        uart.write('4')
                        #x_err = 100
                        #print(1)
                        print(x_err)
                        print("发送4")
                        flag='e'
                        break
                if (abs(y_err) > 2):
                    #print("y")
                    if (y_err < 0):
                        uart.write('1')
                        #y_err = 100
                        print("发送1")
                        flag='e'
                        break
                    if (y_err > 0):
                        uart.write('2')
                        #y_err = 100
                        print("发送2")
                        flag='e'
                        break



