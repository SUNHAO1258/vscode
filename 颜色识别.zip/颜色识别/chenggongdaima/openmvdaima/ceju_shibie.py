import sensor, image, time, math,pyb
from pyb import UART


blue = (32, 54, 0, 57, -63, -23)#(0, 47, -128, 31, -128, -13)
red = (23, 48, 20, 127, -8, 67)#(14, 40, 18, 52, 1, 127)
green =(33, 56, -50, -15, -6, 31)


thresholds = [[red],[green],[blue]]

#初始化坐标
middle_threshold=100
#right_threshold=130
#color_roi = (64,79,209,113)

flag = b"q"
biao = b"q"
FLAG=0
#初始化三个物料的x,y值
group_1x = [0 for x in range(3)]
group_1y= [0 for x in range(3)]
code_1=[0 for x in range(3)]
#code_1=[3,2,1]
code_2=[0 for x in range(3)]
newx=[0,0,0]
jishu=0
jishu_1=0
state_1=0
K=750
xunzhao=[0,0,0]
#初始化区域
uart = UART(3, 115200)
#####寻找停止瞬间的位置
def jieshou():
    global FLAG
    global a
    a=0
    while(FLAG!=6):
        FLAG=0
        if (uart.any()):
            a=uart.read()
            a=str(a)
            #print(a)
            for i in range(0,3):
                code_1[i] = int(a[2+i])
                FLAG=FLAG+1
                print(code_1[i])
            for i in range(0,3):
                code_2[i] = int(a[5+i])
                FLAG=FLAG+1
                print(code_2[i])
def find_stopstate():
    global blobs
    blobs =0
    global state
    state=0
    global yanse
    yanse=[0,0,0]
    global state_1
    #设置原来物料的位置
    group_oldx=[999 for x in range(3)]
    group_oldy=[999 for x in range(3)]
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        #flag = 0
        blobs = img.find_blobs(thresholds[i],pixels_threshold = 100,area_threshold = 100,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                group_oldx[i]=b.cx()
                group_oldy[i]=b.cy()
                yanse[i]=i+1
        else:
            group_oldx[i]=0
            group_oldy[i]=0
    while(state==0):
        get_new()
        if(group_oldx[1]==0 and group_oldx[2]==0 and group_oldx[0]==0 and group_newx[1]==0 and group_newx[2]==0 and group_newx[0]==0):
            state=0
            #print('等待')
        elif(abs(group_oldx[1]-group_newx[1])<2 and abs(group_oldx[2]-group_newx[2])<2 and abs(group_oldx[0]-group_newx[0])<2):
            while(state_1==0):
                    get_new_color()
                    if(yanse[1]-yanse_new[1]==0 and yanse[2]-yanse_new[2]==0 and yanse[0]-yanse_new[0]==0 ):
                        yanse = yanse_new
                    else:
                        state_1=1
                        print(yanse_new)
                        print(yanse)
                        print('jieshou')
                        find_stop()
            state=1
            #print('找到')
        else:
            #print(group_oldx)
            #print(group_newx)
            group_oldx = group_newx
            group_oldy = group_newy
            pass
def find_stop():
    global blobs
    blobs =0
    global state_2
    state_2=0
    #设置原来物料的位置
    group_oldx_1=[999 for x in range(3)]
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        #flag = 0
        blobs = img.find_blobs(thresholds[i],pixels_threshold = 100,area_threshold = 100,merge = True)
        if blobs:
            for b in blobs:
                #img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                group_oldx_1[i]=b.cx()
        else:
            group_oldx_1[i]=0
    while(state_2==0):
        get_new_1()
        if(group_oldx_1[1]==0 and group_oldx_1[2]==0 and group_oldx_1[0]==0 and group_newx[1]==0 and group_newx[2]==0 and group_newx[0]==0):
            state_2=0
            #print('等待')
        elif(abs(group_oldx_1[1]-group_newx_1[1])<1 and abs(group_oldx_1[2]-group_newx_1[2])<1 and abs(group_oldx_1[0]-group_newx_1[0])<1):
            state_2=1
            #print('找到')
        else:
            #print(group_oldx)
            #print(group_newx)
            group_oldx_1 = group_newx_1
            pass
def get_new_color():
    global yanse_new
    yanse_new=[0 for x in range(3)]
    img1 = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        #flag = 0
        blobs = img1.find_blobs(thresholds[i],pixels_threshold = 100,area_threshold = 100,merge = True)
        if blobs:
            for b in blobs:
                yanse_new[i]=i+1
        else:
            pass
def ceju():
    global length
    length=0
    global Lm
    Lm=0
    global biaozhi
    biaozhi=0
    global jishu_1
    global yanse
    yanse=[0,0,0]
    global state_1
    img1 = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        #flag = 0
        blobs = img1.find_blobs(thresholds[i],pixels_threshold =100,area_threshold = 100,merge =True)
        if blobs:
            for b in blobs:
                img1.draw_rectangle(b.rect())
                img1.draw_cross(b.cx(),b.cy())
                Lm = (b[2]+b[3])/2
                length = K/Lm
                print(length)
                #newx[i]=b.cx()
                if(length<20):
                    biaozhi=1
                    xunzhao[i]=i+1
                    break
                else:
                    pass
        else:
            pass
def xunzhao_wuliao():
    global jishu
    global xunzhao
    k=0
    chongxing=1
    global blobs
    blobs =0
    global biaozhi
    while(biaozhi==1):
        for k in range(3):
            if(xunzhao[k]==code_1[jishu]):
                if(k==0):
                    uart.write(str('m'))
                    jishu=jishu+1
                    print('m')
                    #time.sleep(5)
                    #find_stopstate()
                    #sensor.skip_frames(time = 1000)
                    time.sleep(4)
                    break
                if(k==1):
                    uart.write(str('d'))
                    jishu=jishu+1
                    print('d')
                    #time.sleep(5)
                    #find_stopstate()
                    #sensor.skip_frames(time = 1000)
                    time.sleep(4)
                    break
                if(k==2):
                    uart.write(str('l'))
                    jishu=jishu+1
                    print('l')
                    #time.sleep(5)
                    #find_stopstate()
                    #sensor.skip_frames(time = 1000)
                    time.sleep(4)
                    break
            else:
                pass

                #调动中间机械动作组

while(True):
    if (uart.any()):
        flag = uart.read()
        print(flag)
    while(flag == b'c'):
        jieshou()
        break
    if(flag == b's'):
        sensor.reset()
        sensor.set_pixformat(sensor.RGB565)
        sensor.set_framesize(sensor.QVGA)
        sensor.skip_frames(time = 200)
        sensor.set_auto_whitebal(False)
        sensor.set_auto_gain(False)
        while(jishu!=3):
            find_stopstate()
            ceju()
            xunzhao_wuliao()
            #print(jishu)
        uart.write(str('j'))
        print('结')
        flag=b'e'
    #while(flag == b'b'):
        #sensor.reset()
        #sensor.set_pixformat(sensor.RGB565)
        #sensor.set_framesize(sensor.QVGA)
        #sensor.skip_frames(time = 200)
        #sensor.set_auto_whitebal(False)
        #sensor.set_auto_gain(False)
        #jishu=0
        #while(jishu!=3):
            #find_stopstate()
            #xunzhao_wuliao_1()
            ##print(jishu)
        #uart.write(str('s'))
        #print('束')
    while(flag == b'b'):
        sensor.reset()
        sensor.set_pixformat(sensor.RGB565)
        sensor.set_framesize(sensor.QVGA)
        sensor.skip_frames(time = 200)
        sensor.set_auto_whitebal(False)
        sensor.set_auto_gain(False)
        while(jishu_1 != 3):
            find_stopstate()
            xunzhao_wuliao_1()
            #print(jishu)
        uart.write(str('s'))
        print('束')

