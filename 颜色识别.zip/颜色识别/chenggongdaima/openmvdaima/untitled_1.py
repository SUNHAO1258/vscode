import sensor, image, time
from pyb import UART
blue = (17, 48, 10, 22, -54, -18)
red =  (38, 53, 26, 75, -42, 25)
green = (33, 59, -11, 15, -48, 3)

thresholds = [[red],[green],[blue]]
left_roi = [87,0,146,101]

panduan=0
pixels_threshold=100
area_threshold=100
jishu=0
uart = UART(3, 115200)
def yanse_panduan():
    global state
    state=0
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = pixels_threshold,area_threshold = area_threshold,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                #group_oldx[i]=b.cx()
                #group_oldy[i]=b.cy()
                yanse[i]=i+1
        else:
            pass
    while(state==0):
        get_new_color()
        if(yanse[1]-yanse_new[1]==0 and yanse[2]-yanse_new[2]==0 and yanse[0]-yanse_new[0]==0 ):
            yanse = yanse_new
        else:
            state=1
            #print(yanse_new)
            #print(yanse)
            print('jieshou')
            panduan=1

def get_new_color():
    global yanse_new
    yanse_new=[0 for x in range(3)]
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = pixels_threshold,area_threshold = area_threshold,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                #group_newx[i]=b.cx()
                yanse_new[i]=i+1
        else:
            pass

def zhengshi():
    global yanse_zui
    yanse_zui=[0,0,0]
    img = sensor.snapshot().lens_corr(1.5)
    for i in range(3):
        blobs = img.find_blobs(thresholds[i],roi=left_roi,pixels_threshold = pixels_threshold,area_threshold = area_threshold,merge = True)
        if blobs:
            for b in blobs:
                img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                #group_newx[i]=b.cx()
                yanse_zui[i]=i+1
        else:
            pass
def xunzhao_wuliao_1():
    global jishu
    global chongxing
    xunzhao=[0,0,0]
    k=0
    chongxing=1
    global blobs
    blobs =0
    global yanse_zui
    code_1=[2,1,3]
    code_2=[2,1,3]
    for k in range(3):
        if(yanse_zui[k]==code_1[jishu]):
            uart.write(str('o'))
            print('o')
            jishu=jishu+1
            break
        else:
            pass

def panduan():
    global panduan
    if(panduan==0):
        yanse_panduan()
    if(panduan==1):
        zhengshi()
        xunzhao_wuliao_1()






while (True):
    if (uart.any()):
        flag = uart.read()
        print(flag)
    #while(flag == b'c'):
        #jieshou()
        #break
    if(flag == b'k'):
        sensor.reset()
        sensor.set_pixformat(sensor.RGB565)
        sensor.set_framesize(sensor.QVGA)
        sensor.skip_frames(time = 200)
        sensor.set_auto_whitebal(False)
        sensor.set_auto_gain(False)
    while(flag == b's'):
        while(jishu!=3):
            zhengshi()
            xunzhao_wuliao_1()
        uart.write(str('j'))
        print('束')
        flag=b'e'
