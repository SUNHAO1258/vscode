// 1,2,3是红色，绿色，蓝色物料代号
//block[x] 代表x 位置处的物料颜色 x取值为0 1 2 
//code 为二维码中的内容
#include <LobotServoController.h>
#include<arduino.h>
#include <SoftwareSerial.h>
#include<UTFT.h>
// 第一个是RX
SoftwareSerial saoma(A11, A10);
LobotServoController myse(Serial2);
//SDA SCL CS RES DC
UTFT myGLCD(ITDB18SP,37,36,49,40,48);

extern uint8_t SmallFont[];
int block[3] = { 0 };
unsigned long test_time;
// 扫码部分
unsigned char saomiao[9]={};
int group1[3] = {};
int group2[3] = {};
unsigned char Wakecmd[9] = {0x7E, 0x00, 0x08, 0x01, 0x00, 0x02, 0x01, 0xAB, 0xCD};

void setup() {
  pinMode(0,OUTPUT);
  pinMode(1,OUTPUT);
  pinMode(45,OUTPUT);
  digitalWrite(45,HIGH);
// 颜色识别通信串口
  Serial3.begin(115200);
  Serial.begin(9600);
  // 机械臂通信串口
  Serial2.begin(9600);
// 扫码软串口
  saoma.begin(9600);
}
////使用mv进行颜色识别，将物料的颜色分布读取出来
void color_in()
{
    Serial.println("openmvkaishi");
    delay(1000);
    Serial3.print('R');
    delay(100);
    int i = 0;
    test_time = millis();
    int jieshou = 1;
    char temp = "";
    int times;
    // Serial3.print('a');
    while (jieshou == 1)
    {
        if (Serial3.available() > 0)
        {
            temp = Serial3.read();
            if(temp !=""){
              Serial.print("the Serial3 reading data is : ");
              Serial.println(temp);
              delay(2);
            }
        }
        if (temp == '1')
        {
            block[i] = 1;
            i += 1;
          
        }
        else if (temp == '2')
        {
            block[i] = 2;
            i += 1;
            
        }
        else if (temp == '3')
        {
            block[i] = 3;
            i += 1;
            
        }
        else
        {
            block[i] = 0;
        }
        /*
        if ((block[i] == 1) || (block[i] == 2) || (block[i] == 3))
        {
            i += 1;
        }
        */
        if (i >= 3)
        {
            Serial3.print('S');
            delay(5);
            jieshou = 0;
            break;
        }
        temp = "";
        if (long(millis()) > test_time + 4000)
        {
            i = 0;
            times += 1;
            Serial3.print('c');
            delay(5);
            test_time = millis();
        }

    }
    Serial.print("the blocks positon is  ");
    Serial.print(block[0]); Serial.print(block[1]); Serial.print(block[2]);
    Serial.println();
    delay(100);
   }
//  机械臂判断部分
void catach_A_station(){
   for(int i=0;i<3;i++)
    for(int j=0;j<3;j++)
    {
      Serial.print(1);
      if(group1[i]==block[j])
     {
      delay(2000);
      myse.runActionGroup(j,1); 
      delay(2000);
      Serial.print("jixiebidongzuo1: ");
      Serial.println(j);
      delay(1000);
     }
    }
}
void catach_B_station(){
   for(int i=0;i<3;i++)
    for(int j=0;j<3;j++)
    {
      Serial.print(1);
      if(group2[i]==block[j])
     {
      delay(2000);
      myse.runActionGroup(j,1); 
      delay(2000);
      Serial.print("jixiebidongzuo2: ");
      Serial.println(j);
      delay(1000);
     }
    }
}


char change(unsigned char a)
{
 if(a==43)
 {
   a=43;
 }
 else if(a==49)
 {
 a=1; 
 }
else if(a==50)
 {
 a=2; 
 }
else if(a==51)
 {
 a=3; 
 }
 return a;
}

void read_erweima()
{
 unsigned char Num=0;
 unsigned long starttime;
//  String str = ""; 
 saoma.begin(9600);
 saoma.write(Wakecmd,9);
// Serial3.begin(9600);
// Serial3.write(Wakecmd,9);
//等待回收信号结束
// Serial.println(1);

 while (saoma.read() != 0x31);
// while (Serial3.read() != 0x31);
 starttime = millis();
 while (Num<9)
 {// Serial.println(2);
  if(saoma.available() > 0)
  // if(Serial3.available() > 0)
   {//Serial.print(3);
  for(Num=0;Num<9;Num++)
 {
 saomiao[Num]=saoma.read();
// saomiao[Num]=Serial3.read();
//saomiao[Num]=change(saomiao[Num]);
 Serial.print(Num );
 Serial.print(':');
 Serial.println(saomiao[Num]);
//  Serial.println("xaiolongxia");
 }
 }
}
}
void compete()
{
for(int i=0;i<3;i++)
 {
 group1[i]=change(saomiao[i]);
  Serial.println(group1[i]);
 } 
for(int j =0;j<3;j++)
 {
 group2[j]=change(saomiao[j+4]);
  Serial.println(group2[j]);
 }
//  Serial.print("nishi");
}

// 显示部分
void TFCLD_Init()
{
 myGLCD.InitLCD();
 myGLCD.setFont(SmallFont);
 myGLCD.clrScr();
}
void screen()
{ 
 myGLCD.setColor(255, 255, 255);
//  myGLCD.setBackColor(255, 0, 0);
 myGLCD.printNumI(group1[0] ,50 , 50);
 myGLCD.printNumI(group1[1] , 60, 50);
 myGLCD.printNumI(group1[2] ,70, 50);
 myGLCD.print("+", 80, 50);

//  myGLCD.printNumI(group2[0] ,90 , 50);
//  myGLCD.printNumI(group2[1] , 100, 50);
//  myGLCD.printNumI(group2[2] ,110, 50);
 myGLCD.printNumI(group2[0] ,50 , 80);
 myGLCD.printNumI(group2[1] , 60, 80);
 myGLCD.printNumI(group2[2] ,70, 80);
 //SDA SCL CS RES DC
}
void loop() {
  delay(5000);
  read_erweima();
  compete();
  screen();
  Serial.println("saoma");
  color_in(); 
  catach_A_station();  
  color_in(); 
  catach_B_station();
 }