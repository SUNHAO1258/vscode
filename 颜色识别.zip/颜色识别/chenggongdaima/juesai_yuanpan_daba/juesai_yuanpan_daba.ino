#include <LobotServoController.h>
#include <arduino.h>       //arduino基础库
#include <SoftwareSerial.h>  //软串口库
int group1[3] = { 2, 1, 3 };
int group2[3] = { 1, 2, 3 };
int jishu = 0;
// LobotServoController myse(Serial2);
SoftwareSerial Servo_serial(A15, A14);//舵机控制板软串口
void setup() {
  Serial.begin(9600);
  Serial2.begin(9600);
  pinMode(48, OUTPUT);
  digitalWrite(48, HIGH);
  Serial3.begin(115200);
  Serial.begin(9600);
  pinMode(9,INPUT);
}
///通过与舵机控制板通讯，调用机械臂动作组
int ServoActiongroup(int a) //0-15为保存动作组
{
    
    Servo_serial.begin(9600);
    //Serial.println(Servo_serial.isListening());
    char signal_actiongroup[7] = { 0x55, 0x55,0x05, 0x06,0x08,0x01,0x00 }; //舵机动作组信号
    signal_actiongroup[4] = a;
    Servo_serial.write(signal_actiongroup, 7);

}
void chuanshu() {
  // Serial.println("chuanshukaishi");
  // delay(2000);
  Serial3.print('c');
  delay(2000);
  int jieshou = 1;
  int temp_1 = 0;
  int temp_2 = 0;
  int i = 0;
  int j = 0;
  int a = 0;
  char temp = "";
  while (jieshou == 1) {
    for (int i = 0; i < 3; i++) {
      temp_1 = group1[i];
      Serial3.print(temp_1);
    }
    for (int j = 0; j < 3; j++) {
      temp_2 = group2[j];
      Serial3.print(temp_2);
    }
    jieshou = 0;
    Serial.println("wancheng");
  }
}
void shibie_1() {
  int jishu = 0;
  char temp = "";
  int shushu = 0;
  Serial3.print('k');
  delay(2);
  // Serial.println("shibiekaishi");
  // delay(2);
  // B=digitalRead(9);
  // Serial.println(B);
  // Serial3.print('s');
  // Serial.println("shibiekai");
  while(shushu=0){
  if(digitalRead(9)==1){
      Serial3.print('s');
      delay(2);
      if (Serial3.available() > 0) {
        temp = Serial3.read();
        Serial.print("the Serial3 reading data is : ");
        Serial.println(temp);
        delay(2);
      }
      if (temp == 'o') {
         Serial3.print('m'); 
         delay(20);
        // ServoActiongroup(1);
        delay(3000);
      }
      if (temp == 'j') {
         shushu=1;
      }
      temp = 0;
    }
  }
}
void loop() {
  // chuanshu();
  shibie_1();
  Serial.print("jieshu");
}