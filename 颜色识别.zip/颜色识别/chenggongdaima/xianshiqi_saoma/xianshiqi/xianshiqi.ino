#include <UTFT.h>
#include <SoftwareSerial.h>
// 第一个是RX
 SoftwareSerial saoma(A9, A8);
unsigned char Wakecmd[9] = {0x7E, 0x00, 0x08, 0x01, 0x00, 0x02, 0x01, 0xAB, 0xCD};
unsigned char saomiao[9]={};
int group1[3] = {};
int group2[3] = {};
//SDA SCL CS RES DC
UTFT myGLCD(ITDB18SP,43,44,45,46,47);
extern uint8_t SevenSegNumFont[];
extern uint8_t SmallFont[];

void setup() {
saoma.begin(9600);
Serial.begin(9600);
TFCLD_Init();
// Serial3.begin(9600);
}

void read_erweima()
{unsigned char Num=0;
  unsigned long starttime;
  String str = "";
  saoma.begin(9600);
  saoma.write(Wakecmd,9);
  Serial.println(3);
  while (saoma.read() != 0x31);
  starttime = millis();
  Serial.print(1);
  while (Num<9)
  { 
    if(saoma.available() > 0)
     {for(Num=0;Num<9;Num++)
       {
        saomiao[Num]=saoma.read();
        Serial.print(Num );
        Serial.print(':');
        Serial.println(saomiao[Num]);
         }
     }
  }
}
char change(unsigned char a)
{
 if(a==43)
{a=43;
  }
 else if(a==49)
 {
 a=1;
  }
else if(a==50)
 {
 a=2;
 
 }
else if(a==51)
 {
 a=3;
 }
 return a;
}

void compete()
{
for(int i=0;i<3;i++)
 {
  group1[i]=change(saomiao[i]);
} 
for(int j =0;j<3;j++)
 {
group2[j]=change(saomiao[j+4]);
 }
}

void TFCLD_Init()
{
myGLCD.InitLCD();
myGLCD.setFont(SevenSegNumFont);
myGLCD.clrScr();
}
void screen()
{
myGLCD.setColor(255, 255, 255);
//myGLCD.setBackColor(255, 0, 0);
myGLCD.printNumI(group1[0] ,0 , 0);
 myGLCD.printNumI(group1[1] , 50, 0);
 myGLCD.printNumI(group1[2] ,100, 0);
 myGLCD.setFont(SmallFont);
 myGLCD.print("+", 80, 50);
 myGLCD.setFont(SevenSegNumFont);
 myGLCD.printNumI(group2[0] ,0 , 60);
 myGLCD.printNumI(group2[1] , 50, 60);
 myGLCD.printNumI(group2[2] ,100, 60);
//   myGLCD.printNumI(block1[0] ,50 , 80);
//   myGLCD.printNumI(block1[1] , 60, 80);
//   myGLCD.printNumI(block1[2] ,70, 80);
}
void loop(){
// delay(1000);

read_erweima();
Serial.println(2);
compete();
TFCLD_Init();
screen();
}
