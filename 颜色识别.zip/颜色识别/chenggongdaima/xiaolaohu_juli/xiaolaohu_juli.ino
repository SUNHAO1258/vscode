// 修改于12.13日  13：58
// 12.11日 新加入扫码模块并实现
// 可以用方格数线走完全程，但出现新规则
// 当灰度再次成为定位条件，会出现程序未定义（已解决），通过直接定义停止条件
// 新比赛规则 盲走定位，需解决如下问题：1、初始摆放如何与赛道水平 ; 2、初始定位点


#include <Arduino.h>         //arduino基础库
#include <SoftwareSerial.h>  //软串口库
#include <Wire.h>
#include <JY901.h>
#include <LobotServoController.h>
#include <FlexiTimer2.h>  //定时中断头文件库
#define forwardleft digitalRead(8)
#define leftwardfront digitalRead(10)
#define leftwardbehind digitalRead(11)
#define forwardright digitalRead(9)


#define Start 'S'
#define UP 'U'
#define Fish 'F'
#define S_end 'E'
#define R_B '4'
#define R_G '3'
#define B_G '5'
//WHT101相关引脚定义
unsigned char Re_buf[11], counter = 0;
unsigned char sign = 0;
float yaw, yaw_last, yaw_limit;      //偏航角
int TLY = -1;                        //陀螺仪调整
// LobotServoController myse(Serial2);  //舵机控制板定义
int chuxian, times;
char play[2] = { 'A', '2' };
char loud[5] = { 'A', 'F', ':', '3', '0' };
char blue[8] = { 'A', '7', ':', '0', '0', '0', '0', '1' };
char green[8] = { 'A', '7', ':', '0', '0', '0', '0', '2' };
char red[8] = { 'A', '7', ':', '0', '0', '0', '0', '3' };

int Speeds[13] = { 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90 };

//新建SoftwareSerial对象（rx,tx）
SoftwareSerial track_forward(A12, A13);
SoftwareSerial track_leftward(A8, A9);
SoftwareSerial track_rightward(A10, A11);
SoftwareSerial player(A15, A14);
SoftwareSerial Servo_serial(A15, A14);
SoftwareSerial arm(47, 49);
//延时循环定义

unsigned long dark_time = 0;  //规避重复计线时间
unsigned long test_time;
unsigned long avoid_time;
long AVOID_TIME = 3000;
int left_direction, right_direction, right_flag;

//PWM输出引脚定义
#define PWM_A 11
#define PWM_B 12
#define PWM_C 6
#define PWM_D 5

// 电机引脚定义
#define ENA_1 24
#define ENA_2 25
#define ENB_1 30
#define ENB_2 31
#define ENC_1 28
#define ENC_2 29
#define END_1 27
#define END_2 26
//电机编码器AB相引脚定义
#define DIRECTION_A 2  //中断0
#define ENCODER_A 50
#define DIRECTION_B 3  //中断1
#define ENCODER_B 51
#define DIRECTION_C 18  //中断4
#define ENCODER_C 52
#define DIRECTION_D 19  //中断5
#define ENCODER_D 53
//电机PID 参数
float bian = 24;  //编码器变速比
float Velocity_KP = 0.1, Velocity_KI = 0.01, Target = 0, Multiple = 1;     //电机闭环PID参数
int Target_A, Target_B, Target_C, Target_D;  //串口获取的速度字符串变量
int value;                                   //储存PI控制器计算得到的用于调整电机转速的PWM值的整型变量
int Count = 0;
float Velocity_A, Velocity_B, Velocity_C, Velocity_D;
float Velocity_1, Velocity_2, Velocity_3, Velocity_4;
int startPWM = 40;
int PWM_Restrict = 215;
int directionA = -1, directionB = 1, directionC = -1, directionD = 1;
int Motora, Motorb, Motorc, Motord;
int PID_max_bias_MAX = 60, PID_max_bias_MIN = 50;

// 扫码以及显示屏部分
#include <UTFT.h>
#include <SoftwareSerial.h>
// 第一个是RX
SoftwareSerial saoma(A11, A10);
unsigned char Wakecmd[9] = { 0x7E, 0x00, 0x08, 0x01, 0x00, 0x02, 0x01, 0xAB, 0xCD };
unsigned char saomiao[9] = {};
int group1[3] = {};
int group2[3] = {};
//SDA SCL CS RES DC
UTFT myGLCD(ITDB18SP, 43, 44, 45, 46, 47);
extern uint8_t SevenSegNumFont[];
extern uint8_t SmallFont[];

int init_state_1[13] = { 0, 0, 0, 0, 0, 0, 0, 0, 50, 180, 80, 180, 0 };
int init_state[13] = { 0, 0, 0, 0, 0, 0, 0, 0, 100, 180, 120, 180, 0 };
int catch_right[13] = { 0, 0, 0, 0, 0, 0, 0, 0, 60, 180, 120, 180, 0 };
int catch_left[13] = { 0, 0, 0, 0, 0, 0, 0, 0, 60, 180, 60, 180, 0 };
int rotate_right[13] = { 0, 0, 0, 0, 0, 0, 0, 0, 60, 0, 60, 180, 0 };
int rotate_left[13] = { 0, 0, 0, 0, 0, 0, 0, 0, 60, 0, 60, 0, 0 };

/**************************************************************************
  函数功能：mpu6050测yaw偏航角
  入口参数：无
  返回  值：无  //1为高精度陀螺仪 0为低精度陀螺仪
  /**************************************************************************/
void get_mpu(int mode) {
    ////采用双陀螺仪
    if (mode == 1) {
        serialEvent();
        float temp;
        if (sign) {
            sign = 0;
            if (Re_buf[0] == 0x55) {
                switch (Re_buf[1]) {
                    case 0x53:
                        yaw = -(short(Re_buf[7] << 8 | Re_buf[6])) / 32768.0 *
                              180;
                        // Serial.print("the mpu 1:"); Serial.println(yaw);
                        break;
                }
            }
        }
    }
    if (mode == 0) {
        JY901.GetAngle();
        yaw = -((float)JY901.stcAngle.Angle[2] / 32768 * 180);
        // Serial.print("the JY901  ");Serial.println(yaw);
    }
}
// 陀螺仪初始化
void ini_mpu(int mode) {
    if (mode == 1) {
        char mpu_init[5] = {0xFF, 0xAA, 0x76, 0x00, 0x00};
        Serial2.write(mpu_init, 5);
        delay(10);
    }
    if (mode == 0) {
        unsigned char jy601_unlock[2] = {0x88, 0xB5};
        Wire.beginTransmission(0x50);
        Wire.write(0x69);
        for (int i = 0; i < 2; i++) Wire.write(jy601_unlock[i]);
        Wire.endTransmission();

        unsigned char jy601_ini[2] = {0x04, 0x00};
        Wire.beginTransmission(0x50);
        Wire.write(0x01);
        for (int i = 0; i < 2; i++) Wire.write(jy601_ini[i]);
        Wire.endTransmission();
        delay(100);
    }
}
// 一号陀螺仪数据接收
void serialEvent() {
    while (Serial2.available()) {
        Re_buf[counter] = (unsigned char)Serial2.read();
        if (counter == 0 && Re_buf[0] != 0x55) return;  // 第0号数据不是帧头
        counter++;
        if (counter == 11)  // 接收到11个数据
        {
            counter = 0;  // 重新赋值，准备下一帧数据的接收
            sign = 1;
        }
    }
}
void Set_PWM(int motora, int motorb, int motorc, int motord) {
  if (motora < 0) motora = -motora, digitalWrite(ENA_1, HIGH), digitalWrite(ENA_2, LOW), analogWrite(PWM_A, motora);
  else if (motora == 0) digitalWrite(ENA_1, LOW), digitalWrite(ENA_2, LOW);
  else if (motora > 0) digitalWrite(ENA_1, LOW), digitalWrite(ENA_2, HIGH), analogWrite(PWM_A, motora);

  if (motorb > 0) digitalWrite(ENB_1, HIGH), digitalWrite(ENB_2, LOW), analogWrite(PWM_B, motorb);
  else if (motorb == 0) digitalWrite(ENB_1, LOW), digitalWrite(ENB_2, LOW);
  else if (motorb < 0) motorb = -motorb, digitalWrite(ENB_1, LOW), digitalWrite(ENB_2, HIGH), analogWrite(PWM_B, motorb);

  if (motorc > 0) digitalWrite(ENC_1, HIGH), digitalWrite(ENC_2, LOW), analogWrite(PWM_C, motorc);
  else if (motorc == 0) digitalWrite(ENC_1, LOW), digitalWrite(ENC_2, LOW);
  else if (motorc < 0) motorc = -motorc, digitalWrite(ENC_1, LOW), digitalWrite(ENC_2, HIGH), analogWrite(PWM_C, motorc);

  if (motord > 0) digitalWrite(END_1, HIGH), digitalWrite(END_2, LOW), analogWrite(PWM_D, motord);
  else if (motord == 0) digitalWrite(END_1, LOW), digitalWrite(END_2, LOW);
  else if (motord < 0) motord = -motord, digitalWrite(END_1, LOW), digitalWrite(END_2, HIGH), analogWrite(PWM_D, motord);
  // Serial.print(motord);
}
void stop(int s_time) {
  Set_PWM(0, 0, 0, 0);
  delay(s_time);
}
void motor(int a, int b, int c, int d) {
  Target_A = a;
  Target_B = b;
  Target_C = c;
  Target_D = d;
}
void READ_ENCODER_A() {

  if (digitalRead(DIRECTION_A) == LOW) {  //如果是下降沿触发的中断
    if (digitalRead(ENCODER_A) == LOW)
      Velocity_1 += 1;  //根据另外一相电平判定方向

    else Velocity_1 -= 1;

  } else {  //如果是上升沿触发的中断
    if (digitalRead(ENCODER_A) == LOW)
      Velocity_1 -= 1;  //根据另外一相电平判定方向

    else Velocity_1 += 1;
  }
  // Serial.println(digitalRead(DIRECTION_A));
  // Serial.println(digitalRead(ENCODER_A));
}
void READ_ENCODER_B() {

  if (digitalRead(DIRECTION_B) == LOW) {  //如果是下降沿触发的中断
    if (digitalRead(ENCODER_B) == LOW)
      Velocity_2 += 1;  //根据另外一相电平判定方向

    else Velocity_2 -= 1;

  } else {  //如果是上升沿触发的中断
    if (digitalRead(ENCODER_B) == LOW)
      Velocity_2 -= 1;  //根据另外一相电平判定方向

    else Velocity_2 += 1;
  }
  // Serial.println(digitalRead(DIRECTION_B));
  // Serial.println(digitalRead(ENCODER_B));
}
void READ_ENCODER_C() {

  if (digitalRead(DIRECTION_C) == LOW) {  //如果是下降沿触发的中断
    if (digitalRead(ENCODER_C) == LOW)
      Velocity_3 -= 1;  //根据另外一相电平判定方向

    else Velocity_3 += 1;

  } else {  //如果是上升沿触发的中断
    if (digitalRead(ENCODER_C) == LOW)
      Velocity_3 += 1;  //根据另外一相电平判定方向

    else Velocity_3 -= 1;
  }
  // Serial.println(digitalRead(DIRECTION_C));
  // Serial.println(digitalRead(ENCODER_C));
}
void READ_ENCODER_D() {

  if (digitalRead(DIRECTION_D) == LOW) {  //如果是下降沿触发的中断
    if (digitalRead(ENCODER_D) == LOW)
      Velocity_4 -= 1;  //根据另外一相电平判定方向

    else Velocity_4 += 1;

  } else {  //如果是上升沿触发的中断
    if (digitalRead(ENCODER_D) == LOW)
      Velocity_4 += 1;  //根据另外一相电平判定方向

    else Velocity_4 -= 1;
  }
  // Serial.println(digitalRead(DIRECTION_D));
  // Serial.println(digitalRead(ENCODER_D));
}
int Incremental_PI_A(int Encoder, int Target) {
  float Bias;
  static float PWM, Last_bias;
  Bias = Target - Encoder;  //计算偏差
                            // Serial.print(Velocity_A);
                            // Serial.print("     ");
                            // Serial.println(Bias);
                            // Serial.print("     ");
                            //PWM += Velocity_KP / Multiple * (Bias - Last_bias) + Velocity_KI / Multiple / 1.314 * Bias;   //增量式PI控制器
                            // Serial.print(Bias);
  PWM += Velocity_KP * Bias + Velocity_KI * (Bias - Last_bias);
  if (PWM > Target + PID_max_bias_MAX) PWM = Target + PID_max_bias_MAX;  //限幅
  if (PWM < Target - PID_max_bias_MIN) PWM = Target - PID_max_bias_MIN;
  Last_bias = Bias;  //保存上一次偏差
  return PWM;        //增量输出
}
int Incremental_PI_B(int Encoder, int Target) {
  float Bias;
  static float PWM, Last_bias;
  Bias = Target - Encoder;
  // Serial.print(Velocity_B);
  // Serial.print("     ");
  // Serial.println(Bias);
  // Serial.print("     ");                                //计算偏差
  //PWM += Velocity_KP / Multiple * (Bias - Last_bias) + Velocity_KI / Multiple / 1.314 * Bias;   //增量式PI控制器
  // Serial.print(Bias);
  PWM += Velocity_KP * Bias + Velocity_KI * (Bias - Last_bias);
  if (PWM > Target + PID_max_bias_MAX) PWM = Target + PID_max_bias_MAX;  //限幅
  if (PWM < Target - PID_max_bias_MIN) PWM = Target - PID_max_bias_MIN;
  Last_bias = Bias;  //保存上一次偏差
  return PWM;        //增量输出
}
int Incremental_PI_C(int Encoder, int Target) {
  float Bias;
  static float PWM, Last_bias;
  Bias = Target - Encoder;
  // Serial.print(Velocity_C);
  // Serial.print("     ");
  // Serial.println(Bias);
  // Serial.print("     ");                                   //计算偏差
  //PWM += Velocity_KP / Multiple * (Bias - Last_bias) + Velocity_KI / Multiple / 1.314 * Bias;   //增量式PI控制器
  // Serial.print("Bias");
  // Serial.print(Bias);
  PWM += Velocity_KP * Bias + Velocity_KI * (Bias - Last_bias);
  if (PWM > Target + PID_max_bias_MAX) PWM = Target + PID_max_bias_MAX;  //限幅
  if (PWM < Target - PID_max_bias_MIN) PWM = Target - PID_max_bias_MIN;
  Last_bias = Bias;  //保存上一次偏差
  return PWM;        //增量输出
}
int Incremental_PI_D(int Encoder, int Target) {
  float Bias;
  static float PWM, Last_bias;
  Bias = Target - Encoder;
  // Serial.print(Velocity_D);
  // Serial.print("     ");
  // Serial.println(Bias);
  // Serial.print("     ");
  //  Serial.print("     ");
  // Serial.print(Bias);                             //计算偏差
  //PWM += Velocity_KP / Multiple * (Bias - Last_bias) + Velocity_KI / Multiple / 1.314 * Bias;   //增量式PI控制器
  PWM += Velocity_KP * Bias + Velocity_KI * (Bias - Last_bias);
  if (PWM > Target + PID_max_bias_MAX) PWM = Target + PID_max_bias_MAX;  //限幅
  if (PWM < Target - PID_max_bias_MIN) PWM = Target - PID_max_bias_MIN;
  Last_bias = Bias;  //保存上一次偏差
  return PWM;        //增量输出
}
void Motor_PI() {
  // Serial.print(Velocity_A);
  // Serial.print("     ");
  // Serial.print(Velocity_B);
  // Serial.print("     ");
  // Serial.print(Velocity_C);
  // Serial.print("     ");
  // Serial.println(Velocity_D);
  Velocity_A = directionA * Velocity_1 * bian;
  Velocity_B = directionB * Velocity_2 * bian;
  Velocity_C = directionC * Velocity_3 * bian;
  Velocity_D = directionD * Velocity_4 * bian;
  Velocity_1 = 0;
  Velocity_2 = 0;
  Velocity_3 = 0;
  Velocity_4 = 0;
  Motora = Incremental_PI_A(Velocity_A, Target_A);  //===速度PI控制器Target_A
  Motorb = Incremental_PI_B(Velocity_B, Target_B);  //===速度PI控制器
  Motorc = Incremental_PI_C(Velocity_C, Target_C);  //===速度PI控制器
  Motord = Incremental_PI_D(Velocity_D, Target_D);  //===速度PI控制器
  Set_PWM(Motora, Motorb, Motorc, Motord);          //给定PWM
                                                    //Set_PWM(0,0,0,0);
                                                    //  Serial.println(Velocity_A);
                                                    //  Serial.print(' ');
                                                    //  Serial.print(Velocity_B);
                                                    // Serial.print("Motor");
                                                    // Serial.print(Motorc);
                                                    // Serial.print("     ");
                                                    // Serial.println(Motord);
                                                    //  Serial.print(' ');
                                                    //  Serial.println(Velocity_C);
                                                    //  Serial.print(' ');
                                                    //  Serial.println(Velocity_D);
}
/// /////////////////////////////陀螺仪向前全向////////////////////////////////////////////////////////////////////////////////////
void Yaw_move_forward(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  int max_bias_MIN = 50;
  int max_bias_MAX = 60;
  float Yaw_error, Last_error, Integral_error, m1, m2, m3, m4, Yaw_P;
  get_mpu(0);  //获取yaw角
  if ((Yaw_target <= -175) && (Yaw_target >= -190) && (yaw > 160)) {
    yaw = (-1) * (360 - yaw);
  }
  if ((Yaw_target >= 175) && (Yaw_target <= 190) && (yaw < -160)) {
    yaw = 360 - abs(yaw);
  }
  Yaw_error = TLY * (yaw - Yaw_target);  //以下都是PID算法的经典套路，不做过多解释了
  if (abs(Yaw_error) < 10) {
    Yaw_P = 6;
  } else {
    Yaw_P = Kp;
  }
  Integral_error += Yaw_error;

  if (Yaw_error != 0) {

    m1 = pwm1 - (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
    m2 = pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
    m3 = pwm3 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
    m4 = pwm4 - (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
  }

  else {
    m1 = pwm1;
    m2 = pwm2;
    m3 = pwm3;
    m4 = pwm4;
  }

  if (m2 > (pwm2 + max_bias_MAX))
    m2 = (pwm2 + max_bias_MAX);
  if (m1 > (pwm1 + max_bias_MIN))
    m1 = (pwm1 + max_bias_MIN);
  if (m2 < (pwm2 - max_bias_MIN))
    m2 = (pwm2 - max_bias_MIN);
  if (m1 < (pwm1 - max_bias_MAX))
    m1 = (pwm1 - max_bias_MAX);

  if (m3 > (pwm3 + max_bias_MAX))
    m3 = (pwm3 + max_bias_MAX);
  if (m4 > (pwm4 + max_bias_MIN))
    m4 = (pwm4 + max_bias_MIN);
  if (m3 < (pwm3 - max_bias_MIN))
    m3 = (pwm3 - max_bias_MIN);
  if (m4 < (pwm4 - max_bias_MAX))
    m4 = (pwm4 - max_bias_MAX);

  // Set_PWM(m1, m2, m3, m4);
  motor(m1, m2, m3, m4);
  Last_error = Yaw_error;
}
void Yaw_move_forward_time(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    // 匀加速
    if (i = 0) {
      for (i = 0; i < pwm1; i++) {
        Yaw_move_forward(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(20);
      }
    }
    Yaw_move_forward(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      for (i = pwm1; i > 0; i--) {
        Yaw_move_forward(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(20);
      }
      FlexiTimer2::stop();
      break;
    }
  }
}

void forward_S(int Yaw_target, int pwm, float s){
  double v_fb = 0.18681666666 ;
  float s0 = 413.87 ;
  float t ;
  t = (s - s0)/v_fb + 1440 ;
  t = (int)(t) ;
  Yaw_move_forward_time(Yaw_target, pwm, pwm, pwm, pwm, 4, 0.06, 0, t);
  stop(1000);
}
void backward_S(int Yaw_target, int pwm, float s){
  double v_fb = 0.1869625 ;
  float s0 = 345.25 ;
  float t ;
  t = (s - s0)/v_fb + 1440 ;
  t = (int)(t) ;
  Yaw_move_backward_time(Yaw_target, pwm, pwm, pwm, pwm, 4, 0.06, 0, t);
  stop(1000);
}
void left_S(int Yaw_target, int pwm, float s){
  double v_lr = 0.18320625 ;
  float s0 = 402.5295 ;
  float t ;
  t = (s - s0)/v_lr + 1440 ;
  t = (int)(t) ;
  Yaw_move_left_time(Yaw_target, pwm, pwm, pwm, pwm, 4, 0.06, 0, t);
  stop(1000);
}
void right_S(int Yaw_target, int pwm, float s){
  double v_lr = 0.1830625 ;
  float s0 = 404.268 ;
  float t ;
  t = (s - s0)/v_lr + 1440 ;
  t = (int)(t) ;
  Yaw_move_right_time(Yaw_target, pwm, pwm, pwm, pwm, 4, 0.06, 0, t);
  stop(1000);
}
void forward_S_48(int Yaw_target, int pwm, float s){
  double v_fb = 0.1242051282;
  float s0 = 180.6 ;
  float t ;
  t = (s - s0)/v_fb + 960 ;
  t = (int)(t) ;
  Yaw_move_forward_time(Yaw_target, pwm, pwm, pwm, pwm, 4, 0.06, 0, t);
  stop(1000);
}
void Yaw_move_forward_time2(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    Yaw_move_forward(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      FlexiTimer2::stop();
      Set_PWM(0,0,0,0);
      break;
    }
  }
}
void Yaw_move_backward_time2(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    Yaw_move_backward(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      FlexiTimer2::stop();
      Set_PWM(0,0,0,0);
      break;
    }
  }
}
void Yaw_move_left_time2(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    Yaw_move_left(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      FlexiTimer2::stop();
      Set_PWM(0,0,0,0);
      break;
    }
  }
}
void Yaw_move_right_time2(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    Yaw_move_right(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      FlexiTimer2::stop();
      Set_PWM(0,0,0,0);
      break;
    }
  }
}
void Yaw_move_backward(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  int max_bias_MIN = 50;
  int max_bias_MAX = 60;
  float Yaw_error, Last_error, Integral_error, m1, m2, m3, m4, Yaw_P;
  get_mpu(0);  //获取yaw角
  if ((Yaw_target <= -175) && (Yaw_target >= -190) && (yaw > 160)) {
    yaw = (-1) * (360 - yaw);
  }
  if ((Yaw_target >= 175) && (Yaw_target <= 190) && (yaw < -160)) {
    yaw = 360 - abs(yaw);
  }
  Yaw_error = TLY * (Yaw_target - yaw);  //以下都是PID算法的经典套路，不做过多解释了
  if (abs(Yaw_error) < 10) {
    Yaw_P = 6;
  } else {
    Yaw_P = Kp;
  }
  Integral_error += Yaw_error;

  if (Yaw_error != 0) {

    m1 = -(pwm1 - (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
    m2 = -(pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
    m3 = -(pwm3 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
    m4 = -(pwm4 - (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
  }

  else {
    m1 = -pwm1;
    m2 = -pwm2;
    m3 = -pwm3;
    m4 = -pwm4;
  }

  if (m2 > (-pwm2 + max_bias_MIN))
    m2 = (-pwm2 + max_bias_MIN);
  if (m1 > (-pwm1 + max_bias_MAX))
    m1 = (-pwm1 + max_bias_MAX);
  if (m2 < (-pwm2 - max_bias_MAX))
    m2 = (-pwm2 - max_bias_MAX);
  if (m1 < (-pwm1 - max_bias_MIN))
    m1 = (-pwm1 - max_bias_MIN);

  if (m3 > (-pwm3 + max_bias_MIN))
    m3 = (-pwm3 + max_bias_MIN);
  if (m4 > (-pwm4 + max_bias_MAX))
    m4 = (-pwm4 + max_bias_MAX);
  if (m3 < (-pwm3 - max_bias_MAX))
    m3 = (-pwm3 - max_bias_MAX);
  if (m4 < (-pwm4 - max_bias_MIN))
    m4 = (-pwm4 - max_bias_MIN);

  // Set_PWM(m1, m2, m3, m4);
  motor(m1, m2, m3, m4);
  Last_error = Yaw_error;
}
void Yaw_move_backward1(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D){
    int max_bias_MIN = 50;
    int max_bias_MAX = 60;
    float Yaw_error, Last_error, Integral_error, m1, m2, m3, m4, Yaw_P;
    get_mpu(1);        
    if ((yaw > Yaw_target + 3) || (yaw < Yaw_target - 3))
    {
        yaw = yaw_last;
    }
    yaw_last = yaw;
    if ((Yaw_target <= -175) && (Yaw_target >= -190) && (yaw > 160))
    {
        yaw = (-1) * (360 - yaw);
    }
    if ((Yaw_target >= 175) && (Yaw_target <= 190) && (yaw < -160))
    {
        yaw = 360 - abs(yaw);
    }
    Yaw_error = TLY * (Yaw_target - yaw);                 //以下都是PID算法的经典套路，不做过多解释了 
    if (abs(Yaw_error) < 10)
    {
        Yaw_P = 6;
    }
    else
    {
        Yaw_P = Kp;
    }
    Integral_error += Yaw_error;

    if (Yaw_error != 0)
    {

        m1 = -(pwm1 - (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
        m2 = -(pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
        m3 = -(pwm3 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
        m4 = -(pwm4 - (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
    }

    else
    {
        m1 = -pwm1;
        m2 = -pwm2;
        m3 = -pwm3;
        m4 = -pwm4;

    }

    if (m2 > (-pwm2 + max_bias_MIN))
        m2 = (-pwm2 + max_bias_MIN);
    if (m1 > (-pwm1 + max_bias_MAX))
        m1 = (-pwm1 + max_bias_MAX);
    if (m2 < (-pwm2 - max_bias_MAX))
        m2 = (-pwm2 - max_bias_MAX);
    if (m1 < (-pwm1 - max_bias_MIN))
        m1 = (-pwm1 - max_bias_MIN);

    if (m3 > (-pwm3 + max_bias_MIN))
        m3 = (-pwm3 + max_bias_MIN);
    if (m4 > (-pwm4 + max_bias_MAX))
        m4 = (-pwm4 + max_bias_MAX);
    if (m3 < (-pwm3 - max_bias_MAX))
        m3 = (-pwm3 - max_bias_MAX);
    if (m4 < (-pwm4 - max_bias_MIN))
        m4 = (-pwm4 - max_bias_MIN);

  // Set_PWM(m1, m2, m3, m4);
  motor(m1, m2, m3, m4);
  Last_error = Yaw_error;
}
void Yaw_move_backward_time(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (i = 0) {
      for (i = 0; i < pwm1; i++) {
        Yaw_move_backward(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(10);
      }
    }
    Yaw_move_backward(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      // 匀减速
      for (i = pwm1; i > 0; i--) {
        Yaw_move_backward(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(10);
      }
      FlexiTimer2::stop();
      break;
    }
  }
}
void Yaw_move_backward_time_101(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (i = 0) {
      for (i = 0; i < pwm1; i++) {
        Yaw_move_backward1(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(10);
      }
    }
    Yaw_move_backward1(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      // 匀减速
      for (i = pwm1; i > 0; i--) {
        Yaw_move_backward1(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(10);
      }
      FlexiTimer2::stop();
      break;
    }
  }
}
void Yaw_move_left(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Yaw_P, float Yaw_I, float Yaw_D) {
  int max_bias_MIN = 50;
  int max_bias_MAX = 60;
  float Yaw_error, Last_error, Integral_error, m1, m2, m3, m4;
  float Yaw_error_anti, Last_error_anti, Integral_error_anti;

  get_mpu(0);  //获取yaw角

  if ((Yaw_target <= -175) && (Yaw_target >= -190) && (yaw > 100)) {
    yaw = (-1) * (360 - yaw);
  }
  if ((Yaw_target >= 175) && (Yaw_target <= 190) && (yaw < -100)) {
    yaw = 360 - abs(yaw);
  }
  Yaw_error = TLY * (Yaw_target - yaw);  //以下都是PID算法的经典套路，不做过多解释了
  Yaw_error_anti = -Yaw_error;
  Integral_error += Yaw_error;
  Integral_error_anti = -Integral_error;
  if (Yaw_error != 0) {
    if (abs(Yaw_error < 5)) {
      m1 = pwm1 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
      m2 = -(pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
      m3 = pwm3 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D);
      m4 = -(pwm4 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D));
    }
    if (abs(Yaw_error) > 5) {
      m1 = pwm1 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
      m2 = -pwm1;
      m3 = pwm3 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D);
      m4 = -pwm3;
    }
  }

  else {
    m1 = pwm1;
    m2 = -pwm2;
    m3 = pwm3;
    m4 = -pwm4;
  }


  if (m1 > (pwm1 + max_bias_MAX))
    m1 = (pwm1 + max_bias_MAX);
  if (m2 > (-pwm2 + max_bias_MIN))
    m2 = (-pwm2 + max_bias_MIN);
  if (m1 < (pwm1 - max_bias_MIN))
    m1 = (pwm1 - max_bias_MIN);
  if (m2 < (-pwm2 - max_bias_MAX))
    m2 = (-pwm2 - max_bias_MAX);

  if (m3 > (pwm3 + max_bias_MAX))
    m3 = (pwm3 + max_bias_MAX);
  if (m4 > (-pwm4 + max_bias_MIN))
    m4 = (-pwm4 + max_bias_MIN);
  if (m3 < (pwm3 - max_bias_MIN))
    m3 = (pwm3 - max_bias_MIN);
  if (m4 < (-pwm4 - max_bias_MAX))
    m4 = (-pwm4 - max_bias_MAX);

  // Set_PWM(m1, m2, m3, m4);
  motor(m1, m2, m3, m4);
  Last_error = Yaw_error;
  Last_error_anti = -Last_error;
}
void Yaw_move_left_time(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (i = 0) {
      for (i = 0; i < pwm1; i++) {
        Yaw_move_left(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(20);
      }
    }
    Yaw_move_left(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      for (i = pwm1; i > 0; i--) {
        Yaw_move_left(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(20);
      }
      FlexiTimer2::stop();
      break;
    }
  }
}

void Yaw_move_left_time1(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  Now_time = millis();
  while (1) {
    Yaw_move_left(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      break;
    }
  }
}
void Yaw_move_left_turning(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  float Yaw_error, Last_error, Integral_error, m1, m2, m3, m4, Yaw_P;
  float Yaw_error_anti, Last_error_anti, Integral_error_anti;
  get_mpu(0);  //获取yaw角
  if ((Yaw_target <= -175) && (Yaw_target >= -180) && (yaw > 160)) {
    yaw = (-1) * (360 - yaw);
  }
  if ((Yaw_target >= 175) && (Yaw_target <= 180) && (yaw < -160)) {
    yaw = 360 - abs(yaw);
  }
  Yaw_error = TLY * (Yaw_target - yaw);  //以下都是PID算法的经典套路
  if (abs(Yaw_error) < 3) {
    Yaw_P = 6;
  } else {
    Yaw_P = Kp;
  }
  Yaw_error_anti = -Yaw_error;
  Integral_error += Yaw_error;
  Integral_error_anti = -Integral_error;
  if (Yaw_error != 0) {
    if (abs(Yaw_error) < 5) {
      m1 = pwm1 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
      m2 = -(pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
      m3 = pwm3 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D);
      m4 = -(pwm4 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D));
    }
    if (abs(Yaw_error) > 5) {
      m1 = pwm1 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
      m2 = -pwm1;
      m3 = pwm3 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D);
      m4 = -pwm3;
    }
  }

  else {
    m1 = pwm1;
    m2 = -pwm2;
    m3 = pwm3;
    m4 = -pwm4;
  }
  if (m1 > 255)
    m1 = 255;
  if (m2 > 255)
    m2 = 255;
  if (m1 < -255)
    m1 = -255;
  if (m2 < -255)
    m2 = -255;
  if (m3 > 255)
    m3 = 255;
  if (m4 > 255)
    m4 = 255;
  if (m3 < -255)
    m3 = -255;
  if (m4 < -255)
    m4 = -255;

  Set_PWM(m1, m2, m3, m4);
  Last_error = Yaw_error;
  Last_error_anti = -Last_error;
}
void Yaw_move_right(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Yaw_P, float Yaw_I, float Yaw_D) {
  int max_bias_MIN = 50;
  int max_bias_MAX = 60;
  float Yaw_error, Last_error, Integral_error, m1, m2, m3, m4;
  float Yaw_error_anti, Last_error_anti, Integral_error_anti;
  get_mpu(0);
  if ((Yaw_target <= -175) && (Yaw_target >= -190) && (yaw > 160)) {
    yaw = (-1) * (360 - yaw);
  }
  if ((Yaw_target >= 175) && (Yaw_target <= 190) && (yaw < -160)) {
    yaw = 360 - abs(yaw);
  }
  Yaw_error = TLY * (-Yaw_target + yaw);
  Yaw_error_anti = -Yaw_error;
  Integral_error += Yaw_error;
  Integral_error_anti = -Integral_error;

  if (Yaw_error != 0) {
    if (abs(Yaw_error) < 5) {
      m1 = -(pwm1 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
      m2 = pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
      m3 = -(pwm3 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D));
      m4 = pwm4 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D);
    }
    if (abs(Yaw_error) >= 5) {
      m1 = -pwm1;
      m2 = pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
      m3 = -pwm3;
      m4 = pwm4 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D);
    }
  }

  else {
    m1 = -pwm1;
    m2 = pwm2;
    m3 = -pwm3;
    m4 = pwm4;
  }

  if (m2 > (pwm2 + max_bias_MAX))
    m2 = (pwm2 + max_bias_MAX);
  if (m1 > (-pwm1 + max_bias_MIN))
    m1 = (-pwm1 + max_bias_MIN);
  if (m2 < (pwm2 - max_bias_MIN))
    m2 = (pwm2 - max_bias_MIN);
  if (m1 < (-pwm1 - max_bias_MAX))
    m1 = (-pwm1 - max_bias_MAX);

  if (m4 > (pwm4 + max_bias_MAX))
    m4 = (pwm4 + max_bias_MAX);
  if (m3 > (-pwm3 + max_bias_MIN))
    m3 = (-pwm3 + max_bias_MIN);
  if (m4 < (pwm4 - max_bias_MIN))
    m4 = (pwm4 - max_bias_MIN);
  if (m3 < (-pwm3 - max_bias_MAX))
    m3 = (-pwm3 - max_bias_MAX);

  motor(m1, m2, m3, m4);
  Last_error = Yaw_error;
  Last_error_anti = -Last_error;
}
void Yaw_move_right_time(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    // 匀加速
    if (i = 0) {
      for (i = 0; i < pwm1; i++) {
        Yaw_move_right(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(20);
      }
    }
    Yaw_move_right(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      // motor(0,0,0,0);
      // delay(500);
      // 匀减速
      for (i = pwm1; i > 0; i--) {
        Yaw_move_right(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(20);
      }
      FlexiTimer2::stop();
      break;
    }
  }
}
void Yaw_move_right_time1(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    Yaw_move_right(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
    if ((long(millis()) > delay_time + Now_time)) {
      for (i = pwm1; i > 0; i--) {
        Yaw_move_right(Yaw_target, i, i, i, i, Kp, Yaw_I, Yaw_D);
        delay(20);
      }
      FlexiTimer2::stop();
      break;
    }
  }
}
void Yaw_move_right_turning(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Yaw_P, float Yaw_I, float Yaw_D) {
  int max_bias_MIN = 50;
  int max_bias_MAX = 60;
  float Yaw_error, Last_error, Integral_error, m1, m2, m3, m4;
  float Yaw_error_anti, Last_error_anti, Integral_error_anti;
  get_mpu(0);
  if (abs(yaw) > 175) {
    avoid_time = millis();
    if ((yaw < 0) && (yaw - Yaw_target > 0)) {
      left_direction = 1;  //-179到-180
    }
    if ((yaw > 0) && (yaw - Yaw_target < 0)) {
      left_direction = 2;  //179到180
    }
  }
  if (long(millis()) < AVOID_TIME + avoid_time) {
    if ((left_direction == 1) && (yaw > 160)) {
      yaw = (-1) * (360 - yaw);
    }
    if ((left_direction == 2) && (yaw < 20)) {
      yaw += 180;
    }
  }
  Yaw_error = TLY * (-Yaw_target + yaw);

  Yaw_error_anti = -Yaw_error;
  Integral_error += Yaw_error;
  Integral_error_anti = -Integral_error;

  if (Yaw_error != 0) {
    if (abs(Yaw_error) < 5) {
      m1 = -(pwm1 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D));
      m2 = pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
      m3 = -(pwm3 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D));
      m4 = pwm4 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D);
    }
    if (abs(Yaw_error) >= 5) {
      m1 = -pwm1;
      m2 = pwm2 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
      m3 = -pwm3;
      m4 = pwm4 + (Yaw_error_anti * Yaw_P + Integral_error_anti * Yaw_I + (Yaw_error_anti - Last_error_anti) * Yaw_D);
    }
  }

  else {
    m1 = -pwm1;
    m2 = pwm2;
    m3 = -pwm3;
    m4 = pwm4;
  }

  if (m1 > 255)
    m1 = 255;
  if (m2 > 255)
    m2 = 255;
  if (m1 < -255)
    m1 = -255;
  if (m2 < -255)
    m2 = -255;
  if (m3 > 255)
    m3 = 255;
  if (m4 > 255)
    m4 = 255;
  if (m3 < -255)
    m3 = -255;
  if (m4 < -255)
    m4 = -255;
  Set_PWM(m1, m2, m3, m4);
  Last_error = Yaw_error;
  Last_error_anti = -Last_error;
}
void Yaw_TURN_PID(int Target_Yaw, int PWM_MAX, float Yaw_P, float Yaw_I, float Yaw_D) {
  float Yaw_error, Last_error, Integral_error, PWM1, PWM2;
  get_mpu(0);
  if ((Target_Yaw <= -175) && (Target_Yaw >= -180) && (yaw > 90)) {
    yaw = (-1) * (360 - yaw);
  }
  if ((Target_Yaw >= 175) && (Target_Yaw <= 180) && (yaw < -90)) {
    yaw = 360 - abs(yaw);
  }
  Yaw_error = Target_Yaw - yaw;
  Integral_error += Yaw_error;
  if (Yaw_error > 0) {
    PWM1 = 10 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
    PWM2 = -PWM1;
  } else if (Yaw_error < 0) {

    PWM1 = -10 + (Yaw_error * Yaw_P + Integral_error * Yaw_I + (Yaw_error - Last_error) * Yaw_D);
    PWM2 = -PWM1;
  } else {
    PWM1 = PWM2 = 0;
  }
  if (PWM1 > PWM_MAX)
    PWM1 = PWM_MAX;
  if (PWM1 < -PWM_MAX)
    PWM1 = -PWM_MAX;
  if (PWM2 > PWM_MAX)
    PWM2 = PWM_MAX;
  if (PWM2 < -PWM_MAX)
    PWM2 = -PWM_MAX;
  motor(PWM2, PWM1, PWM1, PWM2);
  Last_error = Yaw_error;
}
void Yaw_TURN_PID_time(int Target_Yaw, int PWM_MAX, float Yaw_P, float Yaw_I, float Yaw_D, float delay_time) {
  unsigned long Stop_time, Now_time;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    Yaw_TURN_PID(Target_Yaw, PWM_MAX, Yaw_P, Yaw_I, Yaw_D);
    if (((long(millis()) > delay_time + Now_time) && (yaw == Target_Yaw)) || (long(millis()) > Now_time + 3000)) {
      FlexiTimer2::stop();
      break;
    }
  }
}
void Degree(int Target_degree, int degree_time, int pwm_max) {
  unsigned long Degree_adjust_time;
  Degree_adjust_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (long(millis()) <= degree_time + Degree_adjust_time) {
    Yaw_TURN_PID(Target_degree, pwm_max, 6, 0.1, 0.08);
  }
  FlexiTimer2::stop();
  stop(400);
}
// 扫码以及显示部分
void read_erweima() {
  unsigned char Num = 0;
  unsigned long starttime;
  String str = "";
  saoma.begin(9600);
  saoma.write(Wakecmd, 9);
  Serial.println(3);
  while (saoma.read() != 0x31)
    ;
  starttime = millis();
  Serial.print(1);
  while (Num < 9) {
    if (saoma.available() > 0) {
      for (Num = 0; Num < 9; Num++) {
        saomiao[Num] = saoma.read();
        Serial.print(Num);
        Serial.print(':');
        Serial.println(saomiao[Num]);
      }
    }
  }
}
char change(unsigned char a) {
  if (a == 43) {
    a = 43;
  } else if (a == 49) {
    a = 1;
  } else if (a == 50) {
    a = 2;

  } else if (a == 51) {
    a = 3;
  }
  return a;
}

void compete() {
  for (int i = 0; i < 3; i++) {
    group1[i] = change(saomiao[i]);
  }
  for (int j = 0; j < 3; j++) {
    group2[j] = change(saomiao[j + 4]);
  }
}

void TFCLD_Init() {
  myGLCD.InitLCD();
  myGLCD.setFont(SevenSegNumFont);
  myGLCD.clrScr();
}
void screen() {
  myGLCD.setColor(255, 255, 255);
  //myGLCD.setBackColor(255, 0, 0);
  myGLCD.printNumI(group1[0], 0, 0);
  myGLCD.printNumI(group1[1], 50, 0);
  myGLCD.printNumI(group1[2], 100, 0);
  myGLCD.setFont(SmallFont);
  myGLCD.print("+", 80, 50);
  myGLCD.setFont(SevenSegNumFont);
  myGLCD.printNumI(group2[0], 0, 60);
  myGLCD.printNumI(group2[1], 50, 60);
  myGLCD.printNumI(group2[2], 100, 60);
  //   myGLCD.printNumI(block1[0] ,50 , 80);
  //   myGLCD.printNumI(block1[1] , 60, 80);
  //   myGLCD.printNumI(block1[2] ,70, 80);
}
// 传输识别部分
void chuanshu() {
  Serial.println("chuanshukaishi");
  delay(500);
  Serial3.print('c');
  delay(200);
  int jieshou = 1;
  int temp_1 = 0;
  int temp_2 = 0;
  int i = 0;
  int j = 0;
  int a = 0;
  char temp = "";
  while (jieshou == 1) {
    for (int i = 0; i < 3; i++) {
      temp_1 = group1[i];
      Serial3.print(temp_1);
    }
    for (int j = 0; j < 3; j++) {
      temp_2 = group2[j];
      Serial3.print(temp_2);
    }
    jieshou = 0;
    Serial.println("wancheng");
  }
}
// 打靶部分
void daba1_1() {
  for (int i = 0; i < 3; i++) {
    switch (group1[i]) {
      case 1:
        // delay(1000);
        ServoActiongroup(4);
        delay(14500);
        Serial.print("6");
        break;
      case 2:
        // delay(1000);
        ServoActiongroup(5);
        delay(14500);
        Serial.print("5");
        break;
      case 3:
        // delay(1500);
        ServoActiongroup(6);
        delay(14500);
        Serial.print("4");
        break;
      default:
        printf("Default case\n");
    }
  }
  delay(1000);
  for (int j = 0; j < 3; j++) {
    switch (group1[j]) {
      case 1:
      // delay(1000);
        ServoActiongroup(7);
        delay(14500);
        Serial.print("9");
        break;
      case 2:
        // delay(1000);
        ServoActiongroup(8);
        delay(14500);
        Serial.print("8");
        break;
      case 3:
        // delay(1500);
        ServoActiongroup(9);
        delay(14500);
        Serial.print("7");
        break;
      default:
        printf("Default case\n");
    }
  }
}
void daba2_1() {
  for (int i = 0; i < 3; i++) {
    switch (group2[i]) {
      case 1:
      // delay(1000);
        ServoActiongroup(4);
        delay(14500);
        Serial.print("6");
        break;
      case 2:
        // delay(1000);
        ServoActiongroup(5);
        delay(14500);
        Serial.print("5");
        break;
      case 3:
        // delay(1500);
        ServoActiongroup(6);
        delay(14500);
        Serial.print("4");
        break;
      default:
        printf("Default case\n");
    }
  }
  delay(1000);
  for (int j = 0; j < 3; j++) {
    switch (group2[j]) {
      case 1:
      // delay(1000);
        ServoActiongroup(7);
        delay(14500);
        Serial.print("9");
        break;
      case 2:
        // delay(1000);
        ServoActiongroup(8);
        delay(14500);
        Serial.print("8");
        break;
      case 3:
        // delay(1500);
        ServoActiongroup(9);
        delay(14500);
        Serial.print("7");
        break;
      default:
        printf("Default case\n");
    }
  }
}
void daba1_2() {
  for (int i = 0; i < 3; i++) {
    switch (group1[i]) {
      case 1:
      // delay(1000);
        ServoActiongroup(4);
        delay(14500);
        Serial.print("6");
        break;
      case 2:
        // delay(1000);
        ServoActiongroup(5);
        delay(14500);
        Serial.print("5");
        break;
      case 3:
        // delay(1000);
        ServoActiongroup(6);
        delay(14500);
        Serial.print("4");
        break;
      default:
        printf("Default case\n");
    }
  }
}
void daba2_2() {
  for (int i = 0; i < 3; i++) {
    switch (group2[i]) {
      case 1:
      // delay(1000);
        ServoActiongroup(10);
        delay(14500);
        Serial.print("6");
        break;
      case 2:
        // delay(1000);
        ServoActiongroup(11);
        delay(14500);
        Serial.print("5");
        break;
      case 3:
        // delay(1500);
        ServoActiongroup(12);
        delay(14500);
        // Serial.print("4");
        break;
      default:
        printf("Default case\n");
    }
  }
}
void shibie_1() {
  int biaozhi = 1;
  char temp = "";
  int shushu = 0;
  Serial.println("shibiekaishi");
  delay(2000);
  Serial3.print('s');
  Serial.println("shibiekai");
    while (biaozhi == 1) {
      if (Serial3.available() > 0) {
        temp = Serial3.read();
        Serial.print("the Serial3 reading data is : ");
        Serial.println(temp);
        delay(2);
      }
      if (temp == 'j') {
        biaozhi = 0;
         Serial.print(biaozhi);
      }
      if (temp == 'R') {
        // 中间动作组成
        ServoActiongroup(1);
        // delay(7700);
        delay(7000);
        // ServoActiongroup(0);
        // delay(1000);
        // Serial.print("m1");
        // delay(1000);
      }
      if (temp == 'G') {
        // 中间动作组成
        ServoActiongroup(2);
        // delay(7300);
        delay(7000);
        // ServoActiongroup(0);
        // delay(1000);
        // Serial.print("m2");
        // delay(1500);
      }
      if (temp == 'B') {
        // 中间动作组成
        ServoActiongroup(3);
        delay(7000);
        // delay(5900);
        // ServoActiongroup(0);
        // delay(1000);
        // Serial.print("m3");
        // delay(2000);
      }
      temp = 0;
    }
  }
void shibie_2() {
  int biaozhi = 1;
  char temp = "";
  int shushu = 0;
  Serial.println("shibiekaishi");
  delay(2000);
  Serial3.print('b');
  Serial.println("shibiekai");
    while (biaozhi == 1) {
      if (Serial3.available() > 0) {
        temp = Serial3.read();
        Serial.print("the Serial3 reading data is : ");
        Serial.println(temp);
        delay(2);
      }
      if (temp == 's') {
        biaozhi = 0;
         Serial.print(biaozhi);
      }
      if (temp == 'R') {
        // 中间动作组成
        ServoActiongroup(1);
        // delay(7700);
        delay(7000);
        // ServoActiongroup(0);
        // delay(1000);
        // Serial.print("m1");
        // delay(1000);
      }
      if (temp == 'G') {
        // 中间动作组成
        ServoActiongroup(2);
        // delay(7300);
        delay(7000);
        // ServoActiongroup(0);
        // delay(1000);
        // Serial.print("m2");
        // delay(1500);
      }
      if (temp == 'B') {
        // 中间动作组成
        ServoActiongroup(3);
        // delay(7900);
        delay(7000);
        // ServoActiongroup(0);
        // delay(1000);
        // Serial.print("m3");
        // delay(2000);
      }
      temp = 0;
    }
  }
///通过与舵机控制板通讯，调用机械臂动作组
int ServoActiongroup(int a) //0-15为保存动作组
{
    
    Servo_serial.begin(9600);
    //Serial.println(Servo_serial.isListening());
    char signal_actiongroup[7] = { 0x55, 0x55,0x05, 0x06,0x08,0x01,0x00 }; //舵机动作组信号
    signal_actiongroup[4] = a;
    Servo_serial.write(signal_actiongroup, 7);

}

void dingwei_backward_1(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (digitalRead(10) == 0) {
      Yaw_move_backward(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
      }
    else {
      FlexiTimer2::stop();
      Set_PWM(0, 0, 0, 0);
      break;
    }
  }
}
void dingwei_backward_2(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (digitalRead(8) == 0) {
      Yaw_move_backward(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
      }
    else {
      // stop(200);
      FlexiTimer2::stop();
      Set_PWM(0, 0, 0, 0);
      break;
    }
  }
}
void dingwei_left(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (digitalRead(8) == 0) {
       Yaw_move_left(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
      }
    else {
      FlexiTimer2::stop();
      Set_PWM(0, 0, 0, 0);
      break;
    }
  }
}
void dingwei_right_10(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (digitalRead(10) == 0) {
      Yaw_move_right(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
      }
    else {
      FlexiTimer2::stop();
      Set_PWM(0, 0, 0, 0);
      break;
    }
  }
}
void dingwei_right_8(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (digitalRead(8) == 0) {
      Yaw_move_right(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
      }
    else {
      FlexiTimer2::stop();
      Set_PWM(0, 0, 0, 0);
      break;
    }
  }
}
void dingwei_forward(int Yaw_target, int pwm1, int pwm2, int pwm3, int pwm4, float Kp, float Yaw_I, float Yaw_D) {
  unsigned long Stop_time, Now_time;
  int i = 0;
  Now_time = millis();
  FlexiTimer2::set(5, Motor_PI);  //10毫秒定时中断函数
  FlexiTimer2::start();
  while (1) {
    if (digitalRead(8) == 0) {
      Yaw_move_forward(Yaw_target, pwm1, pwm2, pwm3, pwm4, Kp, Yaw_I, Yaw_D);
      }
    else {
      FlexiTimer2::stop();
      Set_PWM(0, 0, 0, 0);
      break;
    }
  }
}
// 初始化部分
void setup() {
Serial.begin(9600);
// Serial2.begin(9600);
Serial3.begin(115200);
//电机驱动引脚
  pinMode(ENA_1, OUTPUT);
  pinMode(ENA_2, OUTPUT);
  pinMode(ENB_1, OUTPUT);
  pinMode(ENB_2, OUTPUT);
  pinMode(ENC_1, OUTPUT);
  pinMode(ENC_2, OUTPUT);
  pinMode(END_1, OUTPUT);
  pinMode(END_2, OUTPUT);
  
  pinMode(PWM_A, OUTPUT);
  pinMode(PWM_B, OUTPUT);
  pinMode(PWM_C, OUTPUT);
  pinMode(PWM_D, OUTPUT);
//电机编码器  相线和中断开启条件
  pinMode(ENCODER_A, INPUT);
  pinMode(ENCODER_B, INPUT);
  pinMode(ENCODER_C, INPUT);
  pinMode(ENCODER_D, INPUT);
  pinMode(DIRECTION_A, INPUT);
  pinMode(DIRECTION_B, INPUT);
  pinMode(DIRECTION_C, INPUT);
  pinMode(DIRECTION_D, INPUT);
  attachInterrupt(0, READ_ENCODER_A, CHANGE);  //开启外部中断 编码器接口A
  attachInterrupt(1, READ_ENCODER_B, CHANGE);  //开启外部中断 编码器接口B
  attachInterrupt(5, READ_ENCODER_C, CHANGE);  //开启外部中断 编码器接口C
  attachInterrupt(4, READ_ENCODER_D, CHANGE);  //开启外部中断 编码器接口D
//舵机控制板继电器吸合
  pinMode(48, OUTPUT);
  digitalWrite(48, HIGH);
//扫码与显示部分
  saoma.begin(9600);
  TFCLD_Init();
  pinMode(9, INPUT);
  pinMode(8, INPUT);
//陀螺仪
  JY901.StartIIC();
  ini_mpu(0);
  delay(10);

//调整陀螺仪波特率
//char mpu_baud[5] = { 0xFF, 0xAA, 0x04, 0x02, 0x00 };
//Serial2.write(mpu_baud, 5);
delay(10);
}

void loop() {
stop(500);
left_S(0, 72, 420);
forward_S(0,72,600);
//扫码并显示
  read_erweima();  
  compete();
  TFCLD_Init();
  screen();
  chuanshu();
// 调用第一定点动作组
ServoActiongroup(21);
delay(2000);
  ServoActiongroup(20);
  delay(1500);
  forward_S(0,72,986+70);
  // Yaw_move_right_time(0, 48, 48, 48, 48, 2, 0.06, 0, 1290);  
  stop(500);
    // 圆盘定位
  dingwei_backward_1(0,24,24,24,24,2,0.06,0);
  stop(500);
  dingwei_right_8(0,24,24,24,24,2,0.06,0);   
  stop(500);             
// 定位后，小舵机初始状态
ServoActiongroup(21);
delay(2000);
// 机械臂识别状态
ServoActiongroup(0);
delay(2000);
 shibie_1();
 // 调用第二定点动作组 
 delay(500); 
  ServoActiongroup(22);
  delay(2000);
//  机械臂转回小车
ServoActiongroup(25);
  delay(2000);


/**************** 出发第二区域*************************/
int D_C1 =0;
forward_S(0+D_C1,72,314-100);
left_S(0+D_C1,72,875+100);
// 第二区域定位
dingwei_forward(0+D_C1,24,24,24,24,2,0.06,0); 
stop(500);
  dingwei_right_10(0+D_C1,24,24,24,24,2,0.06,0);
  stop(500);
 // 定位后，小舵机初始状态 
  ServoActiongroup(21);
delay(2000);
daba1_1();  
// 调用第三定点动作组 
ServoActiongroup(23);
delay(2000);
ServoActiongroup(25);
  delay(2000);

/**************** 出发第三区域*************************/
int D_C2 =0;
left_S(0+D_C2,72,700-50);   //695
backward_S(0+D_C2,72,870+50);  //875
  Degree(-90+D_C2, 2200, 72);
  // 第三区域定位
  stop(500);
 dingwei_right_10(-90+D_C2,24,24,24,24,2,0.06,0); 
  stop(500);
  dingwei_forward(-90+D_C2,24,24,24,24,2,0.06,0);
  stop(500);
  // 定位后，小舵机初始状态 
  ServoActiongroup(21);
delay(3000);
  daba1_2();
/*********** 准备第二次**************/
int D_C3 =0;
ServoActiongroup(20);
delay(2000);
right_S(-90+D_C3,72,775+40);
backward_S(-90+D_C3,72,1590-50);
Degree(0+D_C3, 2200, 72);
stop(500);
backward_S(0+D_C3,72,214); 
// 圆盘定位                      
  dingwei_backward_1(0+D_C3,24,24,24,24,2,0.06,0);
  stop(500);
  dingwei_right_8(0+D_C3,24,24,24,24,2,0.06,0);   
  stop(500);
   // 定位后，小舵机初始状态 
  ServoActiongroup(21);
delay(2000);
ServoActiongroup(0);
delay(1000);
  // 第二次识别
 shibie_2();
ServoActiongroup(22);
  delay(2000);
//  机械臂转回小车
ServoActiongroup(25);
  delay(2000);


/**************** 出发第二区域*************************/
int D_C4 =-1;
forward_S(0+D_C4,72,314-100);
left_S(0+D_C4,72,875+90);
// 第二区域定位
dingwei_forward(0+D_C4,24,24,24,24,2,0.06,0); 
stop(500);
  dingwei_right_10(0+D_C4,24,24,24,24,2,0.06,0);
  stop(500);
 // 定位后，小舵机初始状态 
  ServoActiongroup(21);
delay(2000);
daba2_1(); 
// 调用第三定点动作组 
delay(1500);
ServoActiongroup(23);
delay(2000);

/**************** 出发第三区域*************************/
int D_C5 =-1;
left_S(0+D_C5,72,700-50);   //695
backward_S(0+D_C5,72,870+50);  //875
  Degree(-90+D_C5, 2200, 72);
  // 第三区域定位
  stop(500);
 dingwei_right_10(-90+D_C5,24,24,24,24,2,0.06,0); 
  stop(500);
  dingwei_forward(-90+D_C5,24,24,24,24,2,0.06,0);
  stop(500);
  // 定位后，小舵机初始状态 
  ServoActiongroup(21);
delay(2000);
  daba2_2();
  delay(1000);
ServoActiongroup(25);
  delay(2000);

left_S(-90+D_C5,72,1000);
forward_S(-90+D_C5,72,350);


stop(100000);
}
