int Run[13] = { 130, 170, 20, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
int guodu[13] = { 130,110,20,180,0,0,0,0,0,0,0,0,0 };
int fang_right[13] = { 140,95,50,155,0,0,0,0,0,0,0,0,0 };
int youbian_zhuangpei[13] = { 126,103,40,150,0,0,0,0,0,0,0,0,0 };
int zhuobian_zhuangpei[13] = { 142,98,45,150,0,0,0,0,0,0,0,0,0 };
//////////////////////////////////////////////////////机械臂动作组//////////////////////////
///通过与舵机控制板通讯，调用机械臂动作组
int ServoActiongroup(int a) //0-15为保存动作组
{
    
    Servo_serial.begin(9600);
    //Serial.println(Servo_serial.isListening());
    char signal_actiongroup[5] = { 0xFF, 0x09, 0, 0x00, 0 }; //舵机动作组信号
    signal_actiongroup[3] = a;
    Servo_serial.write(signal_actiongroup, 5);
}
////设定机械臂动作
int ServoSpeeds(int speeds[])
{
    Servo_serial.begin(9600);
    //Servo_serial.listen();
    char signal_speed[5] = { 0xFF, 0x01, 0, 0, 0x00 };
    int v, i;
    for (i = 0; i < 13; i++)
    {
        v = speeds[i] / 9;
        signal_speed[2] = i;
        signal_speed[3] = v;
        Servo_serial.write(signal_speed, 5);
    }
    delay(30);
   
}
////给定机械臂动作状态
int ServoState(int state[], int t)
{
    
    Servo_serial.begin(9600);
    char signal_state[5] = { 0xFF, 0x02 };
    int a;
    int i;
    for (i = 0; i < 13; i++)
    {
        a = map(state[i], 0, 180, 500, 2500);
        signal_state[2] = i;
        signal_state[3] = a - (a / 256) * 256;
        signal_state[4] = a / 256;
        Servo_serial.write(signal_state, 5);
    }
    delay(t);
    
}
///4 放左边  5 放右  2放前 1放后
///抓取A位置的物料机械臂动作组
void catach_A_station()
{
    int position_A[3] = { 0 };
    for (int j = 0; j < 2; j++)
        for (int i = 0; i < 3; i++)
        {
            if (block[i] == code[j])
            {
                position_A[i] = block[i];
            }
        }
    ServoState(guodu, 1000);
    Serial.print("the positon is  ");
    Serial.print(position_A[2]);
    Serial.print(position_A[1]);
    Serial.print(position_A[0]);
    Serial.println();
    
    if (position_A[1])
    {
        Serial.println("catch middle first in the position A");
        code[0] = position_A[1];
        ServoActiongroup(0); ///抓中间
        delay(5000);
        ServoActiongroup(1);///放后面
        delay(4500);
        ServoState(guodu, 1500);
        //////////////////////////
        if (position_A[2])
        {
            code[1] = position_A[2];
            ServoActiongroup(6);/// 抓左边
            delay(4500);
            ServoActiongroup(2); ////放前面
            delay(4000);
        }
        else
        {
            code[1] = position_A[0];
            ServoActiongroup(3);// 抓右边
            delay(4000);
            ServoActiongroup(2);//放前面
            delay(4500);
        }
        ServoState(guodu, 1500);
        ServoState(Run, 1000);
    }
    else
    {
        code[0] = position_A[0];
        code[1] = position_A[2];
        Serial.println("catach the right first in the positon A");
        
        ServoActiongroup(3);/// 抓右边
        delay(4000);
        ServoActiongroup(1);///放后面
        delay(3500);
        ServoState(guodu, 1500);
        ServoActiongroup(6);// 抓左边
        delay(5000);
        ServoActiongroup(2);//放前面
        delay(4000);
        ServoState(guodu, 1500);
        ServoState(Run, 1000);
    }
}
///4 放左边  5 放右  2放前 1放后
void catch_B_G()
{
    int position_B[3] = { 0 }, raw =  0 ;
    for (int j = 0; j < 2; j++)
        for (int i = 0; i < 3; i++)
            if (block[2-i] == code[j])
            {
                position_B[2-i] = block[2-i];
            }
    Serial.print("in position B need catached position is : ");
    Serial.print(position_B[2]);
    Serial.print(position_B[1]);
    Serial.print(position_B[0]);
    Serial.println();
    ServoState(guodu, 1000);
    if (position_B[1])
    {
        ServoActiongroup(0); ///抓中间
        Serial.println("catach middel");
        delay(5000);
        if (position_B[1] == code[0])
        {
            raw = 4;
            ServoActiongroup(5);
            delay(5500);
            ServoState(guodu, 1500);
        }
        else
        {             
            raw = 5;
            ServoActiongroup(4);//放左边
            delay(5000);
            ServoState(guodu, 1500);
        }

        if (position_B[2])
        {
            ServoActiongroup(6);/// 抓左边
            Serial.println("catach left side");
            delay(5000);
            ServoActiongroup(raw);
            delay(6000);
            ServoState(guodu, 1500);
        }
        else
        {
            ServoActiongroup(3);// 抓右边
            Serial.println("catch right side");
            delay(5000);
            ServoActiongroup(raw);
            delay(6000);
            ServoState(guodu, 1500);
        }
        ServoState(Run, 1000);
    }
    else
    {
        ServoActiongroup(6);/// 抓左边
        Serial.println("catch left side");
        delay(5000);
        if (position_B[2] == code[0])
        {
            raw = 4;
            ServoActiongroup(5);//放右边
            Serial.println("put on right side");

            delay(5000);
            ServoState(guodu, 1000);
        }
        else
        {
            raw = 5;
            ServoActiongroup(4);//放左边
            Serial.println("put on left side");
            delay(5500);
            ServoState(guodu, 1000);
        }
        ServoActiongroup(3);// 抓右边
        Serial.println("catch right side ");
        delay(4500);
        ServoActiongroup(raw);
        delay(5000);
        ServoState(guodu, 1500);
        ServoState(Run, 1000);
    }

    ServoState(Run, 1000);
    ServoState(Run, 1000);
    Serial.println("the arm movement flished ");
}
//机械臂
char mpu_unlock[5] = { 0xFF, 0xAA, 0x69, 0x88, 0xB5 };
Serial2.write(mpu_unlock, 5);
delay(10);

ini_mpu(1);
char mpu_rate[5] = { 0xFF,0xAA,0x03,0x06,0x00 };
Serial2.write(mpu_rate, 5);
delay(10);
JY901.StartIIC();
ini_mpu(0);

//调整陀螺仪波特率
//char mpu_baud[5] = { 0xFF, 0xAA, 0x04, 0x02, 0x00 };
//Serial2.write(mpu_baud, 5);
delay(10);

}
//初始化机械臂，上电动作为初始动作
    digitalWrite(48, 1);
    ServoState(Run, 1000);