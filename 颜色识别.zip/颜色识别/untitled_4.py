# Untitled - By: miao - 周四 4月 29 2021

import sensor, image, time

blue = (80, 32, -14, 59, -105, -43) #blue
red =  (17, 52, 78, 27, 62, -4) #red
green = (42, 90, -24, -56, 16, -34) #green

thresholds = ([red],[blue],[green])

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)

clock = time.clock()

while(True):
    clock.tick()
    img = sensor.snapshot()
    while(True):
        clock.tick()
        img = sensor.snapshot()
        for blob in img.find_blobs(thresholds, pixels_threshold=100, area_threshold=100, merge=True):
            if blob.code() == 3: # r/g code
                img.draw_rectangle(blob.rect())
                img.draw_cross(blob.cx(), blob.cy())
                img.draw_string(blob.x() + 2, blob.y() + 2, "r/g")
            if blob.code() == 5: # r/b code
                img.draw_rectangle(blob.rect())
                img.draw_cross(blob.cx(), blob.cy())
                img.draw_string(blob.x() + 2, blob.y() + 2, "r/b")
            if blob.code() == 6: # g/b code
                img.draw_rectangle(blob.rect())
                img.draw_cross(blob.cx(), blob.cy())
                img.draw_string(blob.x() + 2, blob.y() + 2, "g/b")
            if blob.code() == 7: # r/g/b code
                img.draw_rectangle(blob.rect())
                img.draw_cross(blob.cx(), blob.cy())
                img.draw_string(blob.x() + 2, blob.y() + 2, "r/g/b")
                group[t] = blob[0]

    print(clock.fps())
