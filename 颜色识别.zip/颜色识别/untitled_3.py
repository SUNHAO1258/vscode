import sensor, image, time

blue = (80, 32, -14, 59, -105, -43) #blue
red =  (17, 52, 78, 27, 62, -4) #red
green = (42, 90, -24, -56, 16, -34) #green

thresholds = ([red],[green],[blue])

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_whitebal(False)
sensor.set_auto_gain(False)

clock = time.clock()

red_blobs = None
green_blobs = None
blue_blobs = None

'''def findmax(blobs1,blobs2):    #寻找最大面积的颜色
    max_blob = blob1
    if blob1[4] < blob2[4]:
       max_blob = blob2
    return max_blob'''

while(True):
    clock.tick()
    img = sensor.snapshot()





    ''' 判断不了面积，脑袋疼，是什么逻辑啊。
    i = 0
    for i in range(2):
        colors = img.find_blobs(thresholds[i],pixels_threshold = 2000, area_threshold = 2000,merge = True)
        Flag[i] = True

    for i = 0 in range(2):
        for j = (2 - i) in range(i)
           max_blob = colors[i]
           if Flag[i + 1]:
              max_blob = findmax(colors[i],colors[i + 1])

    for b in max_blob:
        img.draw_rectangle(b[0:4])
        img.draw_cross(b[5],b[6])'''

    #当画面中同时出现三种颜色时无法做到输出其中最大面积的颜色而是只能输出红色
       if red_blobs:
       print('1')
       for b in red_blobs:
           img.draw_rectangle(b[0:4])
           img.draw_cross(b[5],b[6])

    elif blue_blobs:
       print('2')
       for b in blue_blobs:
           img.draw_rectangle(b[0:4])
           img.draw_cross(b[5],b[6])

    elif green_blobs:
        print('3')
        for b in green_blobs:
           img.draw_rectangle(b[0:4])
           img.draw_cross(b[5],b[6])


