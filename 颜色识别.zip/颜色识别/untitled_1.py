# Untitled - By: miao - 周日 4月 25 2021

import sensor,image,time

green_threshold = (37, 100, -67, -9, -47, 127)
#识别到的绿色物料域阈值。依次是(Lmin，Lmax，Amin，Amax，Bmin，Bmax)

ROI=(80,30,15,15)

#一系列设置摄像头操作
sensor.reset() #初始化
sensor.set_pixformat(sensor.RGB565) #设置图像格式
sensor.set_framesize(sensor.QVGA) #设置图像大小
sensor.skip_frames(time = 2000) #跳帧，等待元件设置后趋于稳定

sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
#关闭白平衡，默认打开的，识别色块前一定要都关掉

clock = time.clock() #监控帧率？不知道用来干啥

while(True):
    clock.tick()
    img = sensor.snapshot()
    blobs = img.find_blobs([green_threshold],merge = True)
    #函数返回的是多个[0:9]的列表
    #[0][1]目标图像的左顶点x，y的坐标
    #[2][3]是目标图像的宽高
    #[4]是区域内像素点个数
    #[5][6]是目标图像中心x，y坐标
    #[7][8][9]暂时用不上子

    if blobs:
       for b in blobs:
           img.draw_rectangle(b[0:4])
           img.draw_cross(b[5],b[6])

    print(clock.fps())
