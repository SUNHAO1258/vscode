import sensor, image, time, pyb
from pyb import UART


#------------------初赛物料A-------------------#
blue = (0, 47, -128, 31, -128, -13)
red =  (14, 40, 18, 52, 1, 127)
green = (15, 36, -56, -5, -26, 15)  #(20, 60, 49, 10, -83, -38)  (47, 21, 34, -1, -75, -39)

thresholds = [[red],[green],[blue]]


uart = UART(3, 9600)
numbers = ''

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_whitebal(False)
sensor.set_auto_gain(False)


'''def find_group():
    for i in range(3):
        j = i + 1
        for j in range(3):
            if group_1[i] < group_1[j]:
                group_1[i],group_1[j] = group_1[j],group_1[i]
                numbers_1[i],numbers_1[j] = numbers_1[j],numbers_1[i]
            if group_2[i] < group_2[j]:
                group_2[i],group_2[j] = group_2[j],group_2[i]
                numbers_2[i],numbers_2[j] = numbers_2[j],numbers_2[i]

def Juege_1():
    Sum = numbers_1[0]*100 + numbers_1[1]*10 + numbers_1[2]
    uart.write(str(Sum))

def Juege_2():
    Sum = numbers_2[0]*100 + numbers_2[1]*10 + numbers_2[2]
    uart.write(str(Sum))'''


def find_colors():
    #x = 70
    #x0 = 20

    for i in range(3):
        for b in img.find_blobs(thresholds[i],pixels_threshold = 100,area_threshold = 100,merge = True):
            if b:
                #img.draw_rectangle(b.rect())
                img.draw_cross(b.cx(), b.cy())
                if (b.cy() > 42 and b.cy() < 100):
                    numbers_1[0] = i+1
                elif (b.cy() > 106 and b.cy() < 160):
                    numbers_1[1] = i+1
                elif (b.cy() > 173 and b.cy() < 231):
                    numbers_1[2] = i+1

    #numbers = str(numbers_1[0]) + str(numbers_1[1]) + str(numbers_1[2])


while(True):
    img = sensor.snapshot().lens_corr(1.5)
    numbers_1 = [0,0,0]
    #numbers = ''
    find_colors()
    #print("---------a---------")
    print(numbers_1)
    #print("---------b------------")
    #print(numbers)
    '''if (uart.any()):
        flag = uart.readchar()
        if(flag == 97):
                 #print("物块")
            flag='z'
            for i in range(3):
                if(numbers_1[i]==1):
                    uart.write('1')
                if(numbers_1[i]==2):
                    uart.write('2')
                if(numbers_1[i]==3):
                    uart.write('3')
                   #print(str(numbers_1[i]))
            for i in range(3):
                if(numbers_2[i]==1):
                    uart.write('1')
                if(numbers_2[i]==2):
                    uart.write('2')
                if(numbers_2[i]==3):
                    uart.write('3')
                   #print(str(numbers_2[i]))
        elif(flag == 83):
                   #print("颜色识别收到s")
            break'''
